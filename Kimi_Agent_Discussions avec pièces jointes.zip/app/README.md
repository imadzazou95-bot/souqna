# TFARAJ Rewards — لوحة التحكم الإدارية

لوحة تحكم حقيقية لبوت Telegram للمكافآت، مبنية بـ React + TypeScript + Tailwind + Supabase، وتعمل مباشرة على قاعدة بيانات البوت الموجودة (متوافقة 100% مع مخطط n8n الحالي — لم يتم تعديل أو حذف أي جدول موجود).

## بيانات الدخول الافتراضية

| | |
|---|---|
| البريد | `admin@tfaraj-rewards.com` |
| كلمة المرور | `TFARAJ#Admin2026` |
| الدور | OWNER |

> غيّر كلمة المرور فوراً من Supabase Dashboard → Authentication، وأضف مشرفين جدد بإدخالهم في جدول `admin_users` بأدوار `OWNER / ADMIN / SUPPORT`.

## متغيرات البيئة (.env)

```
VITE_SUPABASE_URL=https://nwgsjacyfjbewzdbuzpd.supabase.co
VITE_SUPABASE_ANON_KEY=<anon key — آمن للمتصفح لأن RLS مفعّل>
```

**ممنوع** وضع `service_role` أو Telegram Bot Token في الواجهة — تُدار في n8n فقط.

## التشغيل محلياً

```bash
npm install
npm run dev      # تطوير
npm run build    # إنتاج → dist/
```

## النشر (Vercel / Netlify)

- أمر البناء: `npm run build` — مجلد الإخراج: `dist`
- أضف متغيري البيئة أعلاه في إعدادات الاستضافة.

## البنية

```
src/
  components/     مكونات مشتركة (StatCard, StatusBadge, EmptyState…)
  layouts/        AdminLayout (Sidebar RTL + Bottom Nav للهاتف)
  hooks/          useAuth (Supabase Auth + admin_users)
  pages/          14 صفحة (Dashboard, Users, Transactions, Withdrawals, Referrals,
                 Ads, Tasks, Daily, Wheel, Broadcast, Security, Audit, Settings, Login)
  services/       طبقة تجريد كاملة — لا منطق داخل المكونات
  lib/            supabase client
supabase/
  migrations/     001_admin_foundation.sql + 002_admin_rpcs.sql (مطبّقة فعلياً)
```

## الأمان

- **RLS** مفعّل على كل الجداول: القراءة للمشرفين المسجلين فقط (`authenticated` + `admin_users`).
- البوت لا يتأثر إطلاقاً (يستخدم `service_role` الذي يتجاوز RLS).
- كل العمليات الحساسة عبر **RPC آمنة** (`security definer`):
  - `admin_adjust_balance` — تعديل رصيد مع سجل معاملة + Audit
  - `admin_process_withdrawal` — قبول/رفض/معالجة/إتمام؛ الرفض يُنشئ معاملة `reversal` ويعيد النقاط
  - `admin_set_user_status` — حظر/اشتباه/تجميد (لا حذف نهائي للمستخدمين)
  - `admin_update_setting` — الإعدادات الحساسة للمالك فقط
  - `admin_create_broadcast` / `admin_cancel_broadcast`
  - `admin_dashboard_stats` / `admin_timeseries` — إحصائيات بتوقيت Africa/Algiers
- فهرس فريد `(type, reference_id)` على `transactions` يمنع منح نفس المكافأة مرتين.

## ربط n8n

الإذاعات تُحفظ كمسودات (`status = draft`) مع قائمة المستلمين في `broadcast_queue` — يلتقطها n8n ويرسلها عبر Telegram Bot API ثم يحدّث `sent/failed`. نقاط الربط المقترحة:

- `/api/webhooks/telegram` — تحديثات البوت
- `/api/webhooks/broadcast` — معالجة الإذاعات
- `/api/webhooks/ad-verification` — التحقق من إكمال الإعلانات
- `/api/webhooks/withdrawal` — إشعارات السحب

## الصلاحيات

| الدور | الصلاحيات |
|---|---|
| OWNER | كل شيء + إعدادات النظام + إدارة المشرفين |
| ADMIN | المستخدمون، السحوبات، الإعلانات، المهام، العجلة، الإذاعة |
| SUPPORT | عرض المستخدمين والمعاملات ومعالجة البلاغات فقط |
