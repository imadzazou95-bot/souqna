-- ============================================================
-- TFARAJ Rewards — Admin RPC Functions (Server Side فقط)
-- كل العمليات الحساسة تمر من هنا، ولا يُسمح للـ Frontend بتعديل الأرصدة مباشرة.
-- ============================================================

-- ===== تعديل رصيد مستخدم (OWNER / ADMIN) =====
create or replace function public.admin_adjust_balance(
  p_user_id bigint, p_amount bigint, p_description text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare v_role text; v_before bigint; v_after bigint;
begin
  v_role := public.current_admin_role();
  if v_role is null or v_role not in ('OWNER','ADMIN') then raise exception 'forbidden'; end if;

  select points into v_before from public.users where id = p_user_id for update;
  if not found then raise exception 'user_not_found'; end if;
  v_after := v_before + p_amount;
  if v_after < 0 then raise exception 'insufficient_balance'; end if;

  update public.users set
    points = v_after,
    total_points_earned = total_points_earned + greatest(p_amount, 0),
    total_points_spent  = total_points_spent  + greatest(-p_amount, 0),
    updated_at = now()
  where id = p_user_id;

  insert into public.transactions (user_id, type, amount, balance_before, balance_after, reference_id, description)
  values (p_user_id, 'admin_adjustment', p_amount, v_before, v_after,
          'admin_adj:' || gen_random_uuid()::text,
          coalesce(p_description, 'تعديل إداري على الرصيد'));

  insert into public.audit_logs (admin_id, admin_email, action, target_type, target_id, new_value)
  values (auth.uid(), (select email from public.admin_users where user_id = auth.uid()),
          'BALANCE_ADJUSTED', 'user', p_user_id::text,
          jsonb_build_object('amount', p_amount, 'before', v_before, 'after', v_after, 'description', p_description));

  return jsonb_build_object('ok', true, 'balance', v_after);
end $$;

-- ===== معالجة طلب سحب: approve / processing / complete / reject =====
create or replace function public.admin_process_withdrawal(
  p_withdrawal_id bigint, p_action text, p_note text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_role text; w public.withdrawals%rowtype; v_new text;
  v_before bigint; v_after bigint; v_action text;
begin
  v_role := public.current_admin_role();
  if v_role is null or v_role not in ('OWNER','ADMIN') then raise exception 'forbidden'; end if;
  if p_action not in ('approve','reject','processing','complete') then raise exception 'invalid_action'; end if;

  select * into w from public.withdrawals where withdrawal_id = p_withdrawal_id for update;
  if not found then raise exception 'not_found'; end if;

  v_new := case p_action
    when 'approve' then 'approved' when 'reject' then 'rejected'
    when 'processing' then 'processing' when 'complete' then 'completed' end;

  if w.status in ('rejected','completed') then raise exception 'invalid_transition'; end if;
  if w.status = 'pending'    and v_new not in ('approved','rejected','processing') then raise exception 'invalid_transition'; end if;
  if w.status = 'processing' and v_new not in ('approved','rejected','completed')  then raise exception 'invalid_transition'; end if;
  if w.status = 'approved'   and v_new not in ('completed','rejected')             then raise exception 'invalid_transition'; end if;

  -- عند الرفض: إرجاع النقاط عبر عملية reversal دون حذف العملية الأصلية
  if v_new = 'rejected' then
    select points into v_before from public.users where id = w.user_id for update;
    v_after := v_before + w.amount;
    update public.users set
      points = v_after,
      total_points_spent = greatest(total_points_spent - w.amount, 0),
      total_withdrawn    = greatest(total_withdrawn - w.amount, 0),
      updated_at = now()
    where id = w.user_id;

    insert into public.transactions (user_id, type, amount, balance_before, balance_after, reference_id, description)
    values (w.user_id, 'reversal', w.amount, v_before, v_after,
            'withdrawal_reversal:' || p_withdrawal_id,
            'استرجاع نقاط طلب السحب المرفوض #' || p_withdrawal_id);
  end if;

  update public.withdrawals set
    status = v_new,
    admin_note = coalesce(p_note, admin_note),
    processed_at = now(),
    processed_by_admin = auth.uid()
  where withdrawal_id = p_withdrawal_id;

  v_action := case v_new
    when 'approved' then 'WITHDRAWAL_APPROVED' when 'rejected' then 'WITHDRAWAL_REJECTED'
    when 'completed' then 'WITHDRAWAL_COMPLETED' else 'WITHDRAWAL_PROCESSING' end;

  insert into public.audit_logs (admin_id, admin_email, action, target_type, target_id, old_value, new_value)
  values (auth.uid(), (select email from public.admin_users where user_id = auth.uid()),
          v_action, 'withdrawal', p_withdrawal_id::text,
          jsonb_build_object('status', w.status),
          jsonb_build_object('status', v_new, 'note', p_note));

  return jsonb_build_object('ok', true, 'status', v_new);
end $$;

-- ===== تحديث حالة مستخدم (حظر / تجميد / اشتباه) — لا حذف نهائي =====
create or replace function public.admin_set_user_status(
  p_user_id bigint, p_status text default null, p_is_banned boolean default null,
  p_is_suspicious boolean default null, p_rewards_frozen boolean default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare v_role text; v_old public.users%rowtype; v_action text := 'USER_UPDATED';
begin
  v_role := public.current_admin_role();
  if v_role is null or v_role not in ('OWNER','ADMIN') then raise exception 'forbidden'; end if;
  if p_status is not null and p_status not in ('active','inactive','banned','suspicious','pending_verification') then
    raise exception 'invalid_status';
  end if;

  select * into v_old from public.users where id = p_user_id;
  if not found then raise exception 'user_not_found'; end if;

  update public.users set
    status = coalesce(p_status, status),
    is_banned = coalesce(p_is_banned, is_banned),
    is_suspicious = coalesce(p_is_suspicious, is_suspicious),
    rewards_frozen = coalesce(p_rewards_frozen, rewards_frozen),
    updated_at = now()
  where id = p_user_id;

  if p_is_banned is not null and p_is_banned and not v_old.is_banned then v_action := 'USER_BLOCKED'; end if;
  if p_is_banned is not null and not p_is_banned and v_old.is_banned then v_action := 'USER_UNBLOCKED'; end if;

  insert into public.audit_logs (admin_id, admin_email, action, target_type, target_id, old_value, new_value)
  values (auth.uid(), (select email from public.admin_users where user_id = auth.uid()),
          v_action, 'user', p_user_id::text,
          jsonb_build_object('status', v_old.status, 'is_banned', v_old.is_banned, 'is_suspicious', v_old.is_suspicious, 'rewards_frozen', v_old.rewards_frozen),
          jsonb_build_object('status', coalesce(p_status, v_old.status), 'is_banned', coalesce(p_is_banned, v_old.is_banned), 'is_suspicious', coalesce(p_is_suspicious, v_old.is_suspicious), 'rewards_frozen', coalesce(p_rewards_frozen, v_old.rewards_frozen)));

  return jsonb_build_object('ok', true);
end $$;

-- ===== تحديث إعدادات النظام (OWNER فقط للإعدادات الحساسة) =====
create or replace function public.admin_update_setting(p_key text, p_value jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_role text; v_old jsonb;
begin
  v_role := public.current_admin_role();
  if v_role is null then raise exception 'forbidden'; end if;
  -- الإعدادات الحساسة للمالك فقط
  if v_role <> 'OWNER' and p_key not like 'wheel\_%' escape '\' and p_key not like 'ad\_%' escape '\'
     and p_key not in ('ads_enabled','daily_reset_mode') then
    raise exception 'owner_only';
  end if;

  select value into v_old from public.settings where key = p_key;
  insert into public.settings (key, value, updated_at) values (p_key, p_value, now())
  on conflict (key) do update set value = excluded.value, updated_at = now();

  insert into public.audit_logs (admin_id, admin_email, action, target_type, target_id, old_value, new_value)
  values (auth.uid(), (select email from public.admin_users where user_id = auth.uid()),
          'SETTINGS_UPDATED', 'setting', p_key, to_jsonb(v_old), p_value);

  return jsonb_build_object('ok', true);
end $$;

-- ===== إنشاء Broadcast (يُحفظ في القاعدة ويلتقطه n8n) =====
create or replace function public.admin_create_broadcast(
  p_title text, p_text text, p_audience text default 'all',
  p_message_type text default 'text', p_media_url text default null,
  p_buttons jsonb default '[]'::jsonb, p_min_balance bigint default null,
  p_user_ids bigint[] default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare v_role text; v_id bigint; v_total int;
begin
  v_role := public.current_admin_role();
  if v_role is null or v_role not in ('OWNER','ADMIN') then raise exception 'forbidden'; end if;
  if p_audience not in ('all','active','channel_members','specific','by_balance') then raise exception 'invalid_audience'; end if;
  if p_message_type not in ('text','image','video','button','inline_keyboard') then raise exception 'invalid_message_type'; end if;

  insert into public.broadcasts (created_by, created_by_admin, title, text, status, audience, message_type, media_url, buttons, target_filter)
  values (null, auth.uid(), p_title, p_text, 'draft', p_audience, p_message_type, p_media_url, coalesce(p_buttons,'[]'::jsonb),
          jsonb_build_object('min_balance', p_min_balance, 'user_ids', p_user_ids))
  returning broadcast_id into v_id;

  insert into public.broadcast_queue (broadcast_id, telegram_id)
  select v_id, u.telegram_id from public.users u
  where u.is_banned = false and u.notifications_on = true
    and case p_audience
      when 'all' then true
      when 'active' then u.last_activity > now() - interval '7 days'
      when 'channel_members' then u.is_channel_member
      when 'by_balance' then u.points >= coalesce(p_min_balance, 0)
      when 'specific' then u.telegram_id = any(coalesce(p_user_ids, array[]::bigint[]))
      else true end;

  select count(*) into v_total from public.broadcast_queue where broadcast_id = v_id;
  update public.broadcasts set total = v_total where broadcast_id = v_id;

  insert into public.audit_logs (admin_id, admin_email, action, target_type, target_id, new_value)
  values (auth.uid(), (select email from public.admin_users where user_id = auth.uid()),
          'BROADCAST_CREATED', 'broadcast', v_id::text,
          jsonb_build_object('title', p_title, 'audience', p_audience, 'recipients', v_total));

  return jsonb_build_object('ok', true, 'broadcast_id', v_id, 'recipients', v_total);
end $$;

-- ===== إلغاء Broadcast =====
create or replace function public.admin_cancel_broadcast(p_broadcast_id bigint)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_role text;
begin
  v_role := public.current_admin_role();
  if v_role is null or v_role not in ('OWNER','ADMIN') then raise exception 'forbidden'; end if;
  update public.broadcasts set status = 'cancelled'
  where broadcast_id = p_broadcast_id and status in ('draft','running');
  update public.broadcast_queue set status = 'failed', error = 'cancelled_by_admin'
  where broadcast_id = p_broadcast_id and status = 'pending';
  return jsonb_build_object('ok', true);
end $$;

-- ===== مراجعة حدث مشبوه (كل الأدوار) =====
create or replace function public.admin_review_suspicious_event(p_event_id bigint, p_reviewed boolean default true)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.is_dashboard_admin() then raise exception 'forbidden'; end if;
  update public.suspicious_events set reviewed = p_reviewed where id = p_event_id;
  return jsonb_build_object('ok', true);
end $$;

-- ===== إحصائيات لوحة التحكم الرئيسية =====
create or replace function public.admin_dashboard_stats()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_tz text := coalesce(public.get_setting_text('timezone','Africa/Algiers'),'Africa/Algiers');
  v_today date; v_yesterday date;
  v jsonb;
begin
  if not public.is_dashboard_admin() then raise exception 'forbidden'; end if;
  v_today := (now() at time zone v_tz)::date;
  v_yesterday := v_today - 1;

  select jsonb_build_object(
    'total_users', (select count(*) from public.users),
    'active_today', (select count(*) from public.users where (last_activity at time zone v_tz)::date = v_today),
    'new_today', (select count(*) from public.users where (created_at at time zone v_tz)::date = v_today),
    'new_yesterday', (select count(*) from public.users where (created_at at time zone v_tz)::date = v_yesterday),
    'active_yesterday', (select count(*) from public.users where (last_activity at time zone v_tz)::date = v_yesterday),
    'total_points_granted', (select coalesce(sum(total_points_earned),0) from public.users),
    'total_points_withdrawn', (select coalesce(sum(amount),0) from public.withdrawals where status = 'completed'),
    'withdrawals_total', (select count(*) from public.withdrawals),
    'withdrawals_pending', (select count(*) from public.withdrawals where status in ('pending','processing')),
    'ads_completed_today', (select count(*) from public.ad_sessions where status = 'completed' and (completed_at at time zone v_tz)::date = v_today),
    'referrals_today', (select count(*) from public.referrals where (created_at at time zone v_tz)::date = v_today),
    'suspicious_users', (select count(*) from public.users where is_suspicious),
    'suspicious_events_open', (select count(*) from public.suspicious_events where not reviewed),
    'channel_members', (select count(*) from public.users where is_channel_member),
    'channel_non_members', (select count(*) from public.users where not is_channel_member),
    'points_granted_today', (select coalesce(sum(amount),0) from public.transactions where amount > 0 and type <> 'reversal' and (created_at at time zone v_tz)::date = v_today),
    'points_granted_yesterday', (select coalesce(sum(amount),0) from public.transactions where amount > 0 and type <> 'reversal' and (created_at at time zone v_tz)::date = v_yesterday)
  ) into v;
  return v;
end $$;

-- ===== سلاسل زمنية لآخر N يوم (Charts) =====
create or replace function public.admin_timeseries(p_days int default 7)
returns table(day date, new_users bigint, active_users bigint, points_granted bigint, points_spent bigint, withdrawals bigint, ads_completed bigint, referrals bigint)
language plpgsql stable security definer set search_path = public as $$
declare v_tz text := coalesce(public.get_setting_text('timezone','Africa/Algiers'),'Africa/Algiers');
begin
  if not public.is_dashboard_admin() then raise exception 'forbidden'; end if;
  return query
  with days as (
    select generate_series(((now() at time zone v_tz)::date - (p_days - 1)), (now() at time zone v_tz)::date, interval '1 day')::date as d
  )
  select
    d.d,
    (select count(*) from public.users u where (u.created_at at time zone v_tz)::date = d.d),
    (select count(*) from public.users u where (u.last_activity at time zone v_tz)::date = d.d),
    (select coalesce(sum(t.amount),0)::bigint::bigint from public.transactions t where t.amount > 0 and t.type <> 'reversal' and (t.created_at at time zone v_tz)::date = d.d),
    (select coalesce(sum(-t.amount),0)::bigint::bigint from public.transactions t where t.amount < 0 and (t.created_at at time zone v_tz)::date = d.d),
    (select count(*) from public.withdrawals w where (w.created_at at time zone v_tz)::date = d.d),
    (select count(*) from public.ad_sessions a where a.status = 'completed' and (a.completed_at at time zone v_tz)::date = d.d),
    (select count(*) from public.referrals r where (r.created_at at time zone v_tz)::date = d.d)
  from days d order by d.d;
end $$;
