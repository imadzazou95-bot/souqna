-- ============================================================
-- TFARAJ Rewards — Admin Dashboard Foundation (ADDITIVE ONLY)
-- لا يعدّل أو يحذف أي بنية موجودة يعتمد عليها البوت.
-- ============================================================

create extension if not exists pgcrypto with schema extensions;

-- ===== 1) admin_users: مشرفو لوحة التحكم (مرتبطون بـ Supabase Auth) =====
create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text,
  role text not null default 'SUPPORT' check (role in ('OWNER','ADMIN','SUPPORT')),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  last_sign_in_at timestamptz
);
alter table public.admin_users enable row level security;

-- ===== 2) audit_logs: سجل الإجراءات الإدارية =====
create table if not exists public.audit_logs (
  id bigint generated always as identity primary key,
  admin_id uuid references public.admin_users(user_id),
  admin_email text,
  action text not null,
  target_type text,
  target_id text,
  old_value jsonb,
  new_value jsonb,
  metadata jsonb,
  created_at timestamptz not null default now()
);
alter table public.audit_logs enable row level security;

create index if not exists audit_logs_created_at_idx on public.audit_logs (created_at desc);

-- ===== 3) Helper functions: التحقق من صلاحية المشرف =====
create or replace function public.current_admin_role()
returns text language sql stable security definer set search_path = public as $$
  select role from public.admin_users where user_id = auth.uid() and is_active limit 1
$$;

create or replace function public.is_dashboard_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.admin_users where user_id = auth.uid() and is_active)
$$;

-- ===== 4) RLS: قراءة كل الجداول للمشرفين فقط (البوت يستخدم service_role ولا يتأثر) =====
do $$
declare t text;
begin
  foreach t in array array[
    'users','transactions','referrals','ad_providers','ad_tasks','ad_sessions',
    'daily_claims','wheel_spins','tasks','task_completions','withdrawals',
    'broadcasts','broadcast_queue','suspicious_events','system_logs',
    'daily_stats','settings','user_state','promo_codes','events'
  ]
  loop
    execute format(
      'drop policy if exists dashboard_admin_select on public.%I;
       create policy dashboard_admin_select on public.%I for select to authenticated using (public.is_dashboard_admin())',
      t, t);
  end loop;
end $$;

-- كتابة مباشرة على جداول الإعدادات التشغيلية فقط (OWNER / ADMIN)
do $$
declare t text;
begin
  foreach t in array array['tasks','ad_tasks','ad_providers']
  loop
    execute format(
      'drop policy if exists dashboard_admin_write on public.%I;
       create policy dashboard_admin_write on public.%I for all to authenticated
         using (public.current_admin_role() in (''OWNER'',''ADMIN''))
         with check (public.current_admin_role() in (''OWNER'',''ADMIN''))',
      t, t);
  end loop;
end $$;

drop policy if exists admin_users_select on public.admin_users;
create policy admin_users_select on public.admin_users for select to authenticated
  using (user_id = auth.uid() or public.is_dashboard_admin());

drop policy if exists admin_users_owner_write on public.admin_users;
create policy admin_users_owner_write on public.admin_users for all to authenticated
  using (public.current_admin_role() = 'OWNER')
  with check (public.current_admin_role() = 'OWNER');

drop policy if exists audit_logs_select on public.audit_logs;
create policy audit_logs_select on public.audit_logs for select to authenticated
  using (public.is_dashboard_admin());

grant select on public.admin_users to authenticated;
grant select, insert, update on public.audit_logs to authenticated;

-- ===== 5) توسعة القيود الحالية بشكل توافقي =====
alter table public.transactions drop constraint if exists transactions_type_check;
alter table public.transactions add constraint transactions_type_check
  check (type = any(array[
    'daily_bonus','wheel_reward','ad_reward','referral_reward','task_reward',
    'withdrawal','admin_adjustment','bonus','penalty','promo_reward','signup_bonus','reversal'
  ]));

alter table public.withdrawals drop constraint if exists withdrawals_status_check;
alter table public.withdrawals add constraint withdrawals_status_check
  check (status = any(array['pending','processing','approved','rejected','completed']));

-- منع منح نفس المكافأة مرتين (لا يؤثر على reference_id الفارغ)
create unique index if not exists transactions_type_reference_uniq
  on public.transactions (type, reference_id) where reference_id is not null;

-- ===== 6) أعمدة إضافية توافقية على broadcasts و withdrawals =====
alter table public.broadcasts alter column created_by drop not null;
alter table public.broadcasts add column if not exists title text;
alter table public.broadcasts add column if not exists audience text not null default 'all';
alter table public.broadcasts add column if not exists message_type text not null default 'text';
alter table public.broadcasts add column if not exists media_url text;
alter table public.broadcasts add column if not exists buttons jsonb not null default '[]'::jsonb;
alter table public.broadcasts add column if not exists target_filter jsonb;
alter table public.broadcasts add column if not exists created_by_admin uuid references public.admin_users(user_id);

alter table public.withdrawals add column if not exists processed_by_admin uuid references public.admin_users(user_id);

-- ===== 7) مفاتيح إعدادات إضافية للوحة (لا تتعارض مع الموجود) =====
insert into public.settings (key, value, description) values
  ('wheel_enabled', 'true', 'تفعيل عجلة الحظ'),
  ('wheel_max_daily_spins', '5', 'أقصى عدد لفات يومياً'),
  ('wheel_min_balance', '0', 'أقل رصيد للّف'),
  ('dashboard_name', '"TFARAJ Rewards"', 'اسم لوحة التحكم')
on conflict (key) do nothing;
