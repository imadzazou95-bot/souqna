import { useCallback, useEffect, useState } from 'react'
import { ListChecks, Plus, Loader2 } from 'lucide-react'
import { taskService } from '@/services/taskService'
import { StatusBadge } from '@/components/StatusBadge'
import { EmptyState } from '@/components/EmptyState'
import { LoadingState, ErrorState, PageHeader } from '@/components/States'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import type { Task } from '@/types'
import { formatDate, formatNumber } from '@/utils/format'

const taskTypes = [
  { value: 'channel', label: 'انضمام لقناة' },
  { value: 'link', label: 'زيارة رابط' },
  { value: 'ad', label: 'مشاهدة إعلان' },
  { value: 'daily', label: 'تسجيل يومي' },
  { value: 'referral', label: 'دعوة أصدقاء' },
  { value: 'custom', label: 'مهمة مخصصة' },
]

const typeLabels: Record<string, string> = Object.fromEntries(taskTypes.map((t) => [t.value, t.label]))

export default function TasksPage() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [counts, setCounts] = useState<Record<number, number>>({})
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)
  const [createOpen, setCreateOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [toast, setToast] = useState<string | null>(null)
  const [form, setForm] = useState({ title: '', description: '', reward: '100', type: 'channel', url: '', max_completions: '' })

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      const [t, c] = await Promise.all([taskService.list(), taskService.getCompletionCounts()])
      setTasks(t)
      setCounts(c)
    } catch (e) {
      console.error(e)
      setError(true)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  const notify = (msg: string) => { setToast(msg); setTimeout(() => setToast(null), 3000) }

  const create = async () => {
    setSaving(true)
    try {
      await taskService.create({
        title: form.title.trim(),
        description: form.description.trim() || null,
        reward: Number(form.reward),
        type: form.type,
        url: form.url.trim() || null,
        status: 'active',
        start_at: null,
        end_at: null,
        max_completions: form.max_completions ? Number(form.max_completions) : null,
        verification_method: form.type === 'channel' ? 'channel_member' : 'manual',
      })
      setCreateOpen(false)
      setForm({ title: '', description: '', reward: '100', type: 'channel', url: '', max_completions: '' })
      notify('تم إنشاء المهمة')
      await load()
    } catch (e) {
      console.error(e)
      notify('حدث خطأ، حاول مرة أخرى')
    } finally {
      setSaving(false)
    }
  }

  const cycleStatus = async (t: Task) => {
    const next = t.status === 'active' ? 'paused' : 'active'
    try {
      await taskService.update(t.id, { status: next })
      notify(next === 'active' ? 'تم تفعيل المهمة' : 'تم إيقاف المهمة')
      await load()
    } catch (e) { console.error(e); notify('حدث خطأ') }
  }

  return (
    <div className="space-y-5">
      <PageHeader title="المهام" subtitle="مهام النقاط التي تظهر للمستخدمين داخل البوت"
        actions={<Button onClick={() => setCreateOpen(true)} className="bg-amber-400 text-amber-950 hover:bg-amber-300 font-bold gap-1.5">
          <Plus className="h-4 w-4" /> مهمة جديدة
        </Button>} />

      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 rounded-xl border border-amber-400/30 bg-[hsl(220,24%,8%)] px-5 py-3 text-sm font-bold shadow-2xl animate-slide-up">{toast}</div>
      )}

      {error ? <ErrorState onRetry={load} /> : loading ? <LoadingState /> : tasks.length === 0 ? (
        <EmptyState icon={ListChecks} title="لا توجد مهام" description="أنشئ أول مهمة ليستطيع المستخدمون كسب النقاط" actionLabel="مهمة جديدة" onAction={() => setCreateOpen(true)} />
      ) : (
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-3">
          {tasks.map((t) => (
            <div key={t.id} className="glass-card p-5 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-bold">{t.title}</h3>
                  <p className="text-xs text-muted-foreground mt-0.5">{typeLabels[t.type] ?? t.type}</p>
                </div>
                <StatusBadge status={t.status} />
              </div>
              {t.description && <p className="text-xs text-muted-foreground leading-relaxed">{t.description}</p>}
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>المكافأة: <span className="num font-bold text-amber-300">{formatNumber(t.reward)}</span></span>
                <span>أُنجزت: <span className="num">{counts[t.id] ?? 0}</span>{t.max_completions ? <span className="num">/{t.max_completions}</span> : ''}</span>
              </div>
              {(t.start_at || t.end_at) && (
                <p className="text-[11px] text-muted-foreground">{formatDate(t.start_at)} ← {formatDate(t.end_at)}</p>
              )}
              {t.status !== 'ended' && (
                <Button size="sm" variant="outline" onClick={() => cycleStatus(t)} className="w-full border-white/10 text-xs">
                  {t.status === 'active' ? 'إيقاف مؤقت' : 'تفعيل'}
                </Button>
              )}
            </div>
          ))}
        </div>
      )}

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="bg-[hsl(220,24%,7%)] border-white/10 text-foreground">
          <DialogHeader><DialogTitle>مهمة جديدة</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <Input placeholder="عنوان المهمة" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="bg-white/[0.03] border-white/10" />
            <Input placeholder="الوصف (اختياري)" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="bg-white/[0.03] border-white/10" />
            <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
              <SelectTrigger className="bg-white/[0.03] border-white/10"><SelectValue /></SelectTrigger>
              <SelectContent className="bg-[hsl(220,24%,8%)] border-white/10">
                {taskTypes.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
              </SelectContent>
            </Select>
            <Input placeholder="الرابط (اختياري)" dir="ltr" value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} className="bg-white/[0.03] border-white/10 text-left" />
            <div className="grid grid-cols-2 gap-3">
              <Input placeholder="المكافأة (نقاط)" type="number" dir="ltr" value={form.reward} onChange={(e) => setForm({ ...form, reward: e.target.value })} className="bg-white/[0.03] border-white/10 text-left" />
              <Input placeholder="حد الإنجاز (اختياري)" type="number" dir="ltr" value={form.max_completions} onChange={(e) => setForm({ ...form, max_completions: e.target.value })} className="bg-white/[0.03] border-white/10 text-left" />
            </div>
            <Button onClick={create} disabled={saving || !form.title} className="w-full bg-amber-400 text-amber-950 hover:bg-amber-300 font-bold">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'إنشاء المهمة'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
