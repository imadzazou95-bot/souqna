import { useCallback, useEffect, useState } from 'react'
import {
  Users, UserCheck, UserPlus, Coins, Wallet, ArrowDownToLine,
  Megaphone, ShieldAlert, Clock,
} from 'lucide-react'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Legend,
} from 'recharts'
import { dashboardService } from '@/services/dashboardService'
import { StatCard } from '@/components/StatCard'
import { ErrorState, PageHeader } from '@/components/States'
import type { DashboardStats, TimeseriesPoint } from '@/types'
import { pctChange } from '@/utils/format'

const tooltipStyle = {
  backgroundColor: 'hsl(220 24% 8%)',
  border: '1px solid rgba(255,255,255,0.1)',
  borderRadius: '12px',
  fontFamily: 'Cairo',
  fontSize: 12,
}

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [series, setSeries] = useState<TimeseriesPoint[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      const [s, t] = await Promise.all([dashboardService.getStats(), dashboardService.getTimeseries(7)])
      setStats(s)
      setSeries(t.map((p) => ({ ...p, day: p.day.slice(5) })))
    } catch (e) {
      console.error(e)
      setError(true)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  if (error) return <ErrorState onRetry={load} />

  return (
    <div className="space-y-6">
      <PageHeader title="لوحة التحكم" subtitle="نظرة عامة على أداء البوت — بتوقيت الجزائر (Africa/Algiers)" />

      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3 md:gap-4">
        <StatCard title="إجمالي المستخدمين" value={stats?.total_users ?? 0} icon={Users} loading={loading} />
        <StatCard title="النشطون اليوم" value={stats?.active_today ?? 0} icon={UserCheck} tone="green"
          change={stats ? pctChange(stats.active_today, stats.active_yesterday) : null} loading={loading} />
        <StatCard title="جدد اليوم" value={stats?.new_today ?? 0} icon={UserPlus} tone="blue"
          change={stats ? pctChange(stats.new_today, stats.new_yesterday) : null} loading={loading} />
        <StatCard title="النقاط الممنوحة" value={stats?.total_points_granted ?? 0} icon={Coins}
          change={stats ? pctChange(stats.points_granted_today, stats.points_granted_yesterday) : null} loading={loading} />
        <StatCard title="النقاط المسحوبة" value={stats?.total_points_withdrawn ?? 0} icon={ArrowDownToLine} tone="orange" loading={loading} />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3 md:gap-4">
        <StatCard title="طلبات السحب" value={stats?.withdrawals_total ?? 0} icon={Wallet} tone="blue" loading={loading} />
        <StatCard title="سحوبات معلقة" value={stats?.withdrawals_pending ?? 0} icon={Clock} tone="orange" loading={loading} />
        <StatCard title="إعلانات مكتملة اليوم" value={stats?.ads_completed_today ?? 0} icon={Megaphone} tone="green" loading={loading} />
        <StatCard title="إحالات اليوم" value={stats?.referrals_today ?? 0} icon={UserPlus} loading={loading} />
        <StatCard title="حسابات مشبوهة" value={stats?.suspicious_users ?? 0} icon={ShieldAlert} tone="red" loading={loading} />
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="glass-card p-5 animate-slide-up">
          <h3 className="font-bold mb-1">المستخدمون الجدد — آخر 7 أيام</h3>
          <p className="text-xs text-muted-foreground mb-4">عدد التسجيلات اليومية</p>
          <div className="h-64" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={series} margin={{ top: 5, right: 5, left: -15, bottom: 0 }}>
                <defs>
                  <linearGradient id="goldFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#e3b341" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#e3b341" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="day" stroke="#667085" fontSize={11} />
                <YAxis stroke="#667085" fontSize={11} allowDecimals={false} />
                <Tooltip contentStyle={tooltipStyle} labelStyle={{ color: '#e3b341' }} />
                <Area type="monotone" dataKey="new_users" name="جدد" stroke="#e3b341" strokeWidth={2.5} fill="url(#goldFill)" />
                <Area type="monotone" dataKey="active_users" name="نشطون" stroke="#38bdf8" strokeWidth={2} fill="transparent" strokeDasharray="5 4" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-card p-5 animate-slide-up">
          <h3 className="font-bold mb-1">النقاط — آخر 7 أيام</h3>
          <p className="text-xs text-muted-foreground mb-4">الممنوحة مقابل المسحوبة</p>
          <div className="h-64" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={series} margin={{ top: 5, right: 5, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="day" stroke="#667085" fontSize={11} />
                <YAxis stroke="#667085" fontSize={11} />
                <Tooltip contentStyle={tooltipStyle} labelStyle={{ color: '#e3b341' }} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="points_granted" name="ممنوحة" fill="#e3b341" radius={[6, 6, 0, 0]} />
                <Bar dataKey="points_spent" name="مسحوبة" fill="#f87171" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-card p-5 animate-slide-up">
          <h3 className="font-bold mb-1">طلبات السحب — آخر 7 أيام</h3>
          <p className="text-xs text-muted-foreground mb-4">عدد الطلبات اليومية</p>
          <div className="h-56" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={series} margin={{ top: 5, right: 5, left: -15, bottom: 0 }}>
                <defs>
                  <linearGradient id="orangeFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#fb923c" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#fb923c" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="day" stroke="#667085" fontSize={11} />
                <YAxis stroke="#667085" fontSize={11} allowDecimals={false} />
                <Tooltip contentStyle={tooltipStyle} />
                <Area type="monotone" dataKey="withdrawals" name="سحوبات" stroke="#fb923c" strokeWidth={2.5} fill="url(#orangeFill)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-card p-5 animate-slide-up">
          <h3 className="font-bold mb-1">نشاط الإعلانات والإحالات — آخر 7 أيام</h3>
          <p className="text-xs text-muted-foreground mb-4">إعلانات مكتملة وإحالات جديدة</p>
          <div className="h-56" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={series} margin={{ top: 5, right: 5, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="day" stroke="#667085" fontSize={11} />
                <YAxis stroke="#667085" fontSize={11} allowDecimals={false} />
                <Tooltip contentStyle={tooltipStyle} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="ads_completed" name="إعلانات" fill="#34d399" radius={[6, 6, 0, 0]} />
                <Bar dataKey="referrals" name="إحالات" fill="#a78bfa" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {stats && (
        <div className="glass-card p-5">
          <h3 className="font-bold mb-4">القناة الإجبارية <span className="text-amber-400 text-sm font-semibold num">@TFARAJTV1</span></h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="rounded-xl border border-emerald-400/15 bg-emerald-400/5 p-4 text-center">
              <p className="text-3xl font-extrabold num text-emerald-300">{stats.channel_members}</p>
              <p className="text-xs text-muted-foreground mt-1">مشتركون بالقناة</p>
            </div>
            <div className="rounded-xl border border-white/10 bg-white/[0.02] p-4 text-center">
              <p className="text-3xl font-extrabold num">{stats.channel_non_members}</p>
              <p className="text-xs text-muted-foreground mt-1">غير مشتركين / غادروا</p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
