import { useCallback, useEffect, useState } from 'react'
import { ScrollText, ChevronRight, ChevronLeft } from 'lucide-react'
import { auditService } from '@/services/securityService'
import { EmptyState } from '@/components/EmptyState'
import { LoadingState, ErrorState, PageHeader } from '@/components/States'
import { Button } from '@/components/ui/button'
import type { AuditLog } from '@/types'
import { formatDate } from '@/utils/format'

const PAGE_SIZE = 30

const actionLabels: Record<string, string> = {
  USER_BLOCKED: 'حظر مستخدم', USER_UNBLOCKED: 'فك حظر مستخدم', USER_UPDATED: 'تحديث مستخدم',
  BALANCE_ADJUSTED: 'تعديل رصيد', WITHDRAWAL_APPROVED: 'قبول سحب', WITHDRAWAL_REJECTED: 'رفض سحب',
  WITHDRAWAL_COMPLETED: 'إتمام سحب', WITHDRAWAL_PROCESSING: 'سحب قيد المعالجة',
  SETTINGS_UPDATED: 'تحديث إعدادات', BROADCAST_CREATED: 'إنشاء إذاعة',
}

export default function AuditLogsPage() {
  const [logs, setLogs] = useState<AuditLog[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      const res = await auditService.list(page, PAGE_SIZE)
      setLogs(res.logs)
      setTotal(res.total)
    } catch (e) {
      console.error(e)
      setError(true)
    } finally {
      setLoading(false)
    }
  }, [page])

  useEffect(() => { load() }, [load])

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE))

  return (
    <div className="space-y-5">
      <PageHeader title="سجل الإجراءات" subtitle="كل إجراء إداري مهم موثّق هنا (Audit Trail)" />

      {error ? <ErrorState onRetry={load} /> : loading ? <LoadingState /> : logs.length === 0 ? (
        <EmptyState icon={ScrollText} title="لا توجد إجراءات مسجلة" description="ستُسجّل هنا كل الإجراءات الإدارية الحساسة تلقائياً" />
      ) : (
        <>
          <div className="space-y-2">
            {logs.map((log) => (
              <div key={log.id} className="glass-card px-4 py-3.5 flex flex-wrap items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-bold text-sm">{actionLabels[log.action] ?? log.action}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {log.admin_email ?? '—'} · {log.target_type} <span className="num">{log.target_id}</span>
                  </p>
                  {(log.new_value || log.old_value) && (
                    <p className="text-[11px] text-muted-foreground/70 mt-1 truncate max-w-md" dir="ltr">
                      {JSON.stringify(log.new_value ?? log.old_value)}
                    </p>
                  )}
                </div>
                <span className="text-[11px] text-muted-foreground whitespace-nowrap">{formatDate(log.created_at)}</span>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-between">
            <p className="text-xs text-muted-foreground">صفحة <span className="num">{page + 1}</span> من <span className="num">{totalPages}</span></p>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled={page === 0} onClick={() => setPage(page - 1)} className="border-white/10 gap-1">
                <ChevronRight className="h-4 w-4" /> السابق
              </Button>
              <Button variant="outline" size="sm" disabled={page >= totalPages - 1} onClick={() => setPage(page + 1)} className="border-white/10 gap-1">
                التالي <ChevronLeft className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
