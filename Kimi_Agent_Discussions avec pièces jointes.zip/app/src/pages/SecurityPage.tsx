import { useCallback, useEffect, useState } from 'react'
import { ShieldAlert, ShieldCheck, Loader2 } from 'lucide-react'
import { securityService } from '@/services/securityService'
import { StatusBadge } from '@/components/StatusBadge'
import { EmptyState } from '@/components/EmptyState'
import { LoadingState, ErrorState, PageHeader } from '@/components/States'
import { Button } from '@/components/ui/button'
import type { SuspiciousEvent } from '@/types'
import { formatDate, formatNumber, timeAgo } from '@/utils/format'
import { cn } from '@/lib/utils'

const reasonLabels: Record<string, string> = {
  self_referral: 'إحالة ذاتية',
  duplicate_referral: 'إحالة مكررة',
  multiple_claims: 'مطالبات مشبوهة متكررة',
  abnormal_ad_activity: 'نشاط إعلاني غير طبيعي',
  failed_verification: 'فشل تحقق متكرر',
  multi_account: 'مؤشرات حسابات متعددة',
}

export default function SecurityPage() {
  const [users, setUsers] = useState<any[]>([])
  const [events, setEvents] = useState<SuspiciousEvent[]>([])
  const [filter, setFilter] = useState<'open' | 'reviewed'>('open')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)
  const [actionId, setActionId] = useState<number | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      const [u, e] = await Promise.all([
        securityService.getSuspiciousUsers(),
        securityService.getEvents(filter === 'open' ? false : true),
      ])
      setUsers(u)
      setEvents(e)
    } catch (e) {
      console.error(e)
      setError(true)
    } finally {
      setLoading(false)
    }
  }, [filter])

  useEffect(() => { load() }, [load])

  const review = async (id: number) => {
    setActionId(id)
    try {
      await securityService.reviewEvent(id, true)
      await load()
    } catch (e) { console.error(e) } finally {
      setActionId(null)
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader title="الأمان والاشتباه" subtitle="البيانات المشبوهة لا تُحذف — تُجمّد المكافآت فقط إلى حين المراجعة" />

      <div className="glass-card p-5">
        <h3 className="font-bold mb-4">الحسابات المشبوهة / المجمّدة <span className="num text-orange-300">({users.length})</span></h3>
        {users.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">لا توجد حسابات مشبوهة حالياً</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/[0.06] text-muted-foreground text-xs">
                  <th className="text-right font-semibold px-3 py-2.5">المستخدم</th>
                  <th className="text-right font-semibold px-3 py-2.5">الرصيد</th>
                  <th className="text-right font-semibold px-3 py-2.5">الحالة</th>
                  <th className="text-right font-semibold px-3 py-2.5">المكافآت</th>
                  <th className="text-right font-semibold px-3 py-2.5">آخر نشاط</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} className="border-b border-white/[0.04]">
                    <td className="px-3 py-2.5">
                      <div className="font-semibold text-xs">{u.first_name ?? '—'}</div>
                      <div className="text-[11px] text-muted-foreground num">{u.telegram_id}</div>
                    </td>
                    <td className="px-3 py-2.5 num font-bold text-amber-300">{formatNumber(u.points)}</td>
                    <td className="px-3 py-2.5">
                      <StatusBadge status={u.is_banned ? 'banned' : u.is_suspicious ? 'suspicious' : u.status} />
                    </td>
                    <td className="px-3 py-2.5">
                      {u.rewards_frozen
                        ? <span className="text-xs text-violet-300 font-semibold">مجمّدة</span>
                        : <span className="text-xs text-emerald-400">نشطة</span>}
                    </td>
                    <td className="px-3 py-2.5 text-[11px] text-muted-foreground">{timeAgo(u.last_activity)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="flex gap-2">
        {(['open', 'reviewed'] as const).map((f) => (
          <button key={f} onClick={() => setFilter(f)}
            className={cn('rounded-full px-4 py-1.5 text-xs font-bold border transition-all',
              filter === f ? 'bg-amber-400/15 text-amber-300 border-amber-400/30' : 'text-muted-foreground border-white/10 hover:bg-white/5')}>
            {f === 'open' ? 'قيد المراجعة' : 'تمت مراجعتها'}
          </button>
        ))}
      </div>

      {error ? <ErrorState onRetry={load} /> : loading ? <LoadingState /> : events.length === 0 ? (
        <EmptyState icon={ShieldCheck} title="لا توجد أحداث مشبوهة" description="النظام نظيف — ستظهر هنا أي أنشطة غير طبيعية يرصدها البوت" />
      ) : (
        <div className="space-y-3">
          {events.map((e) => (
            <div key={e.id} className="glass-card p-4 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-start gap-3 min-w-0">
                <div className={cn('rounded-xl border p-2 shrink-0',
                  e.severity >= 4 ? 'border-red-400/25 bg-red-400/10 text-red-400' : 'border-orange-400/25 bg-orange-400/10 text-orange-300')}>
                  <ShieldAlert className="h-4 w-4" />
                </div>
                <div className="min-w-0">
                  <p className="font-bold text-sm">{reasonLabels[e.reason] ?? e.reason}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    مستخدم <span className="num">{e.telegram_id}</span> · خطورة <span className="num">{e.severity}/5</span> · {formatDate(e.created_at)}
                  </p>
                </div>
              </div>
              {filter === 'open' && (
                <Button size="sm" variant="outline" disabled={actionId === e.id} onClick={() => review(e.id)}
                  className="border-emerald-400/30 text-emerald-300 gap-1.5">
                  {actionId === e.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ShieldCheck className="h-3.5 w-3.5" />}
                  تمت المراجعة
                </Button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
