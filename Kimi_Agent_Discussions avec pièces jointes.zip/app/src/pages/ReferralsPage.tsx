import { useCallback, useEffect, useState } from 'react'
import { UserPlus } from 'lucide-react'
import { referralService } from '@/services/referralService'
import { StatusBadge } from '@/components/StatusBadge'
import { EmptyState } from '@/components/EmptyState'
import { LoadingState, ErrorState, PageHeader } from '@/components/States'
import { formatDate, formatNumber } from '@/utils/format'
import { cn } from '@/lib/utils'

const tabs = [
  { key: 'all', label: 'الكل' },
  { key: 'pending', label: 'قيد الانتظار' },
  { key: 'rewarded', label: 'مؤهل' },
  { key: 'frozen', label: 'مجمّد / مشبوه' },
  { key: 'rejected', label: 'مرفوض' },
]

export default function ReferralsPage() {
  const [referrals, setReferrals] = useState<any[]>([])
  const [stats, setStats] = useState<{ total: number; pending: number; rewarded: number; frozen: number; rejected: number } | null>(null)
  const [status, setStatus] = useState('all')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      const [list, s] = await Promise.all([referralService.list(status), referralService.getStats()])
      setReferrals(list.referrals)
      setStats(s)
    } catch (e) {
      console.error(e)
      setError(true)
    } finally {
      setLoading(false)
    }
  }, [status])

  useEffect(() => { load() }, [load])

  return (
    <div className="space-y-5">
      <PageHeader title="الإحالات" subtitle="المكافأة تُمنح فقط بعد التحقق من الاشتراك بالقناة وسلامة الحساب" />

      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {[
            { label: 'الإجمالي', value: stats.total, cls: 'text-foreground' },
            { label: 'قيد الانتظار', value: stats.pending, cls: 'text-sky-300' },
            { label: 'مؤهل', value: stats.rewarded, cls: 'text-emerald-300' },
            { label: 'مجمّد / مشبوه', value: stats.frozen, cls: 'text-violet-300' },
            { label: 'مرفوض', value: stats.rejected, cls: 'text-red-300' },
          ].map((s) => (
            <div key={s.label} className="glass-card p-4 text-center">
              <p className={cn('text-2xl font-extrabold num', s.cls)}>{formatNumber(s.value)}</p>
              <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      )}

      <div className="flex gap-2 overflow-x-auto pb-1">
        {tabs.map((t) => (
          <button key={t.key} onClick={() => setStatus(t.key)}
            className={cn('whitespace-nowrap rounded-full px-4 py-1.5 text-xs font-bold border transition-all',
              status === t.key ? 'bg-amber-400/15 text-amber-300 border-amber-400/30' : 'text-muted-foreground border-white/10 hover:bg-white/5')}>
            {t.label}
          </button>
        ))}
      </div>

      {error ? <ErrorState onRetry={load} /> : loading ? <LoadingState /> : referrals.length === 0 ? (
        <EmptyState icon={UserPlus} title="لا توجد إحالات" description="ستظهر الإحالات الجديدة هنا عند دعوة المستخدمين لأصدقائهم" />
      ) : (
        <div className="glass-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/[0.06] text-muted-foreground text-xs">
                  <th className="text-right font-semibold px-4 py-3">المُحيل</th>
                  <th className="text-right font-semibold px-4 py-3">المُحال</th>
                  <th className="text-right font-semibold px-4 py-3">الحالة</th>
                  <th className="text-right font-semibold px-4 py-3">مشترك بالقناة</th>
                  <th className="text-right font-semibold px-4 py-3">المكافأة</th>
                  <th className="text-right font-semibold px-4 py-3">التاريخ</th>
                </tr>
              </thead>
              <tbody>
                {referrals.map((r) => (
                  <tr key={r.id} className="border-b border-white/[0.04] hover:bg-white/[0.02]">
                    <td className="px-4 py-3">
                      <div className="font-semibold text-xs">{r.inviter?.first_name ?? '—'}</div>
                      <div className="text-[11px] text-muted-foreground num">{r.inviter_id}</div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-semibold text-xs">{r.invited?.first_name ?? '—'}</div>
                      <div className="text-[11px] text-muted-foreground num">{r.invited_id}</div>
                    </td>
                    <td className="px-4 py-3"><StatusBadge status={r.status} /></td>
                    <td className="px-4 py-3 text-xs">{r.invited?.is_channel_member ? 'نعم' : 'لا'}</td>
                    <td className="px-4 py-3 num font-bold text-amber-300">{formatNumber(r.reward)}</td>
                    <td className="px-4 py-3 text-[11px] text-muted-foreground whitespace-nowrap">{formatDate(r.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
