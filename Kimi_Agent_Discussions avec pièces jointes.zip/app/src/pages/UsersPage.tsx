import { useCallback, useEffect, useState } from 'react'
import { useNavigate } from 'react-router'
import { Search, Users as UsersIcon, ChevronRight, ChevronLeft, BadgeCheck, BadgeX } from 'lucide-react'
import { userService, type UserFilters } from '@/services/userService'
import { StatusBadge } from '@/components/StatusBadge'
import { EmptyState } from '@/components/EmptyState'
import { LoadingState, ErrorState, PageHeader } from '@/components/States'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import type { BotUser } from '@/types'
import { formatNumber, timeAgo, displayName } from '@/utils/format'
import { cn } from '@/lib/utils'

const PAGE_SIZE = 20

const filterTabs = [
  { key: 'all', label: 'الكل' },
  { key: 'active', label: 'نشط' },
  { key: 'blocked', label: 'محظور' },
  { key: 'suspicious', label: 'مشبوه' },
  { key: 'channel_member', label: 'مشترك بالقناة' },
  { key: 'not_channel_member', label: 'غير مشترك' },
] as const

export default function UsersPage() {
  const navigate = useNavigate()
  const [users, setUsers] = useState<BotUser[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(0)
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState<UserFilters['status']>('all')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      const res = await userService.list({ search, status: filter }, page, PAGE_SIZE)
      setUsers(res.users)
      setTotal(res.total)
    } catch (e) {
      console.error(e)
      setError(true)
    } finally {
      setLoading(false)
    }
  }, [search, filter, page])

  useEffect(() => {
    const t = setTimeout(load, 300)
    return () => clearTimeout(t)
  }, [load])

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE))

  return (
    <div className="space-y-5">
      <PageHeader title="المستخدمون" subtitle={`${formatNumber(total)} مستخدم مسجل`} />

      <div className="glass-card p-4 space-y-3">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="بحث بـ Telegram ID أو اسم المستخدم أو الاسم…"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(0) }}
            className="pr-10 bg-white/[0.03] border-white/10 h-11"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {filterTabs.map((t) => (
            <button
              key={t.key}
              onClick={() => { setFilter(t.key); setPage(0) }}
              className={cn(
                'whitespace-nowrap rounded-full px-4 py-1.5 text-xs font-bold border transition-all',
                filter === t.key
                  ? 'bg-amber-400/15 text-amber-300 border-amber-400/30'
                  : 'text-muted-foreground border-white/10 hover:bg-white/5'
              )}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {error ? (
        <ErrorState onRetry={load} />
      ) : loading ? (
        <LoadingState />
      ) : users.length === 0 ? (
        <EmptyState icon={UsersIcon} title="لا يوجد مستخدمون" description="لم يتم العثور على مستخدمين مطابقين لبحثك أو الفلتر المحدد" />
      ) : (
        <>
          {/* Desktop table */}
          <div className="hidden md:block glass-card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/[0.06] text-muted-foreground text-xs">
                    <th className="text-right font-semibold px-4 py-3.5">المستخدم</th>
                    <th className="text-right font-semibold px-4 py-3.5">Telegram ID</th>
                    <th className="text-right font-semibold px-4 py-3.5">الرصيد</th>
                    <th className="text-right font-semibold px-4 py-3.5">إجمالي الأرباح</th>
                    <th className="text-right font-semibold px-4 py-3.5">الإحالات</th>
                    <th className="text-right font-semibold px-4 py-3.5">القناة</th>
                    <th className="text-right font-semibold px-4 py-3.5">الحالة</th>
                    <th className="text-right font-semibold px-4 py-3.5">آخر نشاط</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((u) => (
                    <tr
                      key={u.id}
                      onClick={() => navigate(`/users/${u.id}`)}
                      className="border-b border-white/[0.04] hover:bg-amber-400/[0.04] cursor-pointer transition-colors"
                    >
                      <td className="px-4 py-3">
                        <div className="font-semibold">{displayName(u)}</div>
                        {u.username && <div className="text-xs text-muted-foreground num">@{u.username}</div>}
                      </td>
                      <td className="px-4 py-3 num text-muted-foreground">{u.telegram_id}</td>
                      <td className="px-4 py-3 num font-bold text-amber-300">{formatNumber(u.points)}</td>
                      <td className="px-4 py-3 num">{formatNumber(u.total_points_earned)}</td>
                      <td className="px-4 py-3 num">{u.referral_count}</td>
                      <td className="px-4 py-3">
                        {u.is_channel_member
                          ? <BadgeCheck className="h-4 w-4 text-emerald-400" />
                          : <BadgeX className="h-4 w-4 text-muted-foreground/50" />}
                      </td>
                      <td className="px-4 py-3">
                        <StatusBadge status={u.is_banned ? 'banned' : u.is_suspicious ? 'suspicious' : u.status} />
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{timeAgo(u.last_activity)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Mobile cards */}
          <div className="md:hidden space-y-3">
            {users.map((u) => (
              <button
                key={u.id}
                onClick={() => navigate(`/users/${u.id}`)}
                className="glass-card w-full text-right p-4 space-y-2 hover:border-amber-400/20 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-bold">{displayName(u)}</p>
                    <p className="text-xs text-muted-foreground num">{u.telegram_id}</p>
                  </div>
                  <StatusBadge status={u.is_banned ? 'banned' : u.is_suspicious ? 'suspicious' : u.status} />
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground text-xs">الرصيد</span>
                  <span className="num font-bold text-amber-300">{formatNumber(u.points)} نقطة</span>
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>إحالات: <span className="num">{u.referral_count}</span></span>
                  <span>{u.is_channel_member ? 'مشترك بالقناة' : 'غير مشترك'}</span>
                  <span>{timeAgo(u.last_activity)}</span>
                </div>
              </button>
            ))}
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between">
            <p className="text-xs text-muted-foreground">صفحة <span className="num">{page + 1}</span> من <span className="num">{totalPages}</span></p>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled={page === 0} onClick={() => setPage(page - 1)} className="border-white/10 gap-1">
                <ChevronRight className="h-4 w-4" /> السابق
              </Button>
              <Button variant="outline" size="sm" disabled={page >= totalPages - 1} onClick={() => setPage(page + 1)} className="border-white/10 gap-1">
                التالي <ChevronLeft className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
