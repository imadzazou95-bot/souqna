import { useCallback, useEffect, useState } from 'react'
import { CalendarCheck } from 'lucide-react'
import { dailyService, settingsService } from '@/services/settingsService'
import { EmptyState } from '@/components/EmptyState'
import { LoadingState, ErrorState, PageHeader } from '@/components/States'
import type { DailyClaim } from '@/types'
import { formatNumber, timeAgo } from '@/utils/format'
import { cn } from '@/lib/utils'

export default function DailyPage() {
  const [data, setData] = useState<{ total: number; today: number; recent: DailyClaim[]; timezone: string } | null>(null)
  const [mode, setMode] = useState<string>('reset')
  const [rewards, setRewards] = useState<number[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      const [d, settings] = await Promise.all([dailyService.getStats(), settingsService.getAll()])
      setData(d)
      setMode(String(settings.daily_reset_mode ?? 'reset'))
      setRewards(Array.from({ length: 7 }, (_, i) => Number(settings[`daily_day_${i + 1}`] ?? 0)))
    } catch (e) {
      console.error(e)
      setError(true)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  return (
    <div className="space-y-5">
      <PageHeader title="المكافأة اليومية" subtitle="تُحسب الأيام بتوقيت Africa/Algiers — منع المطالبة المزدوجة عبر قيود قاعدة البيانات" />

      {error ? <ErrorState onRetry={load} /> : loading ? <LoadingState /> : data && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="glass-card p-4 text-center">
              <p className="text-2xl font-extrabold num">{formatNumber(data.total)}</p>
              <p className="text-xs text-muted-foreground mt-1">إجمالي المطالبات</p>
            </div>
            <div className="glass-card p-4 text-center">
              <p className="text-2xl font-extrabold num text-amber-300">{formatNumber(data.today)}</p>
              <p className="text-xs text-muted-foreground mt-1">مطالبات اليوم</p>
            </div>
            <div className="glass-card p-4 text-center">
              <p className="text-2xl font-extrabold" dir="ltr">{data.timezone}</p>
              <p className="text-xs text-muted-foreground mt-1">المنطقة الزمنية</p>
            </div>
            <div className="glass-card p-4 text-center">
              <p className={cn('text-2xl font-extrabold', mode === 'reset' ? 'text-emerald-300' : 'text-sky-300')}>{mode.toUpperCase()}</p>
              <p className="text-xs text-muted-foreground mt-1">وضع إعادة التعيين</p>
            </div>
          </div>

          <div className="glass-card p-5">
            <h3 className="font-bold mb-4">جدول مكافآت الأيام السبعة</h3>
            <div className="grid grid-cols-7 gap-2">
              {rewards.map((r, i) => (
                <div key={i} className="rounded-xl border border-amber-400/15 bg-amber-400/5 p-3 text-center">
                  <p className="text-[10px] text-muted-foreground">يوم {i + 1}</p>
                  <p className="num font-extrabold text-amber-300 text-sm mt-1">{formatNumber(r)}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card p-5">
            <h3 className="font-bold mb-4">آخر المطالبات</h3>
            {data.recent.length === 0 ? (
              <EmptyState icon={CalendarCheck} title="لا توجد مطالبات بعد" description="ستظهر المطالبات اليومية هنا فور بدء المستخدمين" />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/[0.06] text-muted-foreground text-xs">
                      <th className="text-right font-semibold px-3 py-2.5">المستخدم</th>
                      <th className="text-right font-semibold px-3 py-2.5">تاريخ المطالبة</th>
                      <th className="text-right font-semibold px-3 py-2.5">يوم السلسلة</th>
                      <th className="text-right font-semibold px-3 py-2.5">المكافأة</th>
                      <th className="text-right font-semibold px-3 py-2.5">الوقت</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.recent.map((c) => (
                      <tr key={c.id} className="border-b border-white/[0.04]">
                        <td className="px-3 py-2.5 num">{c.user_id}</td>
                        <td className="px-3 py-2.5 num">{c.claim_date}</td>
                        <td className="px-3 py-2.5 num">{c.streak_day}</td>
                        <td className="px-3 py-2.5 num font-bold text-emerald-400">+{formatNumber(c.reward)}</td>
                        <td className="px-3 py-2.5 text-xs text-muted-foreground">{timeAgo(c.created_at)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  )
}
