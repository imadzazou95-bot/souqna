import { useCallback, useEffect, useState } from 'react'
import { Wallet, CheckCircle2, XCircle, Clock, Loader2, Eye } from 'lucide-react'
import { withdrawalService } from '@/services/withdrawalService'
import { StatusBadge } from '@/components/StatusBadge'
import { EmptyState } from '@/components/EmptyState'
import { LoadingState, ErrorState, PageHeader } from '@/components/States'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { useAuth } from '@/hooks/useAuth'
import type { Withdrawal, WithdrawalStatus } from '@/types'
import { formatDate, formatNumber, displayName } from '@/utils/format'
import { cn } from '@/lib/utils'

const tabs: { key: WithdrawalStatus | 'all'; label: string }[] = [
  { key: 'all', label: 'الكل' },
  { key: 'pending', label: 'معلق' },
  { key: 'processing', label: 'قيد المعالجة' },
  { key: 'approved', label: 'مقبول' },
  { key: 'completed', label: 'مكتمل' },
  { key: 'rejected', label: 'مرفوض' },
]

export default function WithdrawalsPage() {
  const { admin } = useAuth()
  const canProcess = admin?.role === 'OWNER' || admin?.role === 'ADMIN'
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([])
  const [status, setStatus] = useState<WithdrawalStatus | 'all'>('all')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)
  const [selected, setSelected] = useState<Withdrawal | null>(null)
  const [note, setNote] = useState('')
  const [actionLoading, setActionLoading] = useState(false)
  const [toast, setToast] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      const res = await withdrawalService.list(status)
      setWithdrawals(res.withdrawals)
    } catch (e) {
      console.error(e)
      setError(true)
    } finally {
      setLoading(false)
    }
  }, [status])

  useEffect(() => { load() }, [load])

  const process = async (action: 'approve' | 'reject' | 'processing' | 'complete') => {
    if (!selected) return
    setActionLoading(true)
    try {
      await withdrawalService.process(selected.withdrawal_id, action, note || undefined)
      setToast(action === 'reject' ? 'تم الرفض وإرجاع النقاط للمستخدم (REVERSAL)' : 'تم تحديث الطلب بنجاح')
      setSelected(null)
      setNote('')
      await load()
    } catch (e) {
      console.error(e)
      setToast('حدث خطأ، حاول مرة أخرى')
    } finally {
      setActionLoading(false)
      setTimeout(() => setToast(null), 3500)
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader title="طلبات السحب" subtitle="معالجة طلبات سحب النقاط — الرفض يعيد النقاط تلقائياً عبر عملية استرجاع" />

      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 rounded-xl border border-amber-400/30 bg-[hsl(220,24%,8%)] px-5 py-3 text-sm font-bold shadow-2xl animate-slide-up">
          {toast}
        </div>
      )}

      <div className="flex gap-2 overflow-x-auto pb-1">
        {tabs.map((t) => (
          <button key={t.key} onClick={() => setStatus(t.key)}
            className={cn('whitespace-nowrap rounded-full px-4 py-1.5 text-xs font-bold border transition-all',
              status === t.key ? 'bg-amber-400/15 text-amber-300 border-amber-400/30' : 'text-muted-foreground border-white/10 hover:bg-white/5')}>
            {t.label}
          </button>
        ))}
      </div>

      {error ? <ErrorState onRetry={load} /> : loading ? <LoadingState /> : withdrawals.length === 0 ? (
        <EmptyState icon={Wallet} title="لا توجد طلبات سحب حالياً" description="ستظهر طلبات السحب الجديدة هنا فور إنشائها من البوت" />
      ) : (
        <div className="glass-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/[0.06] text-muted-foreground text-xs">
                  <th className="text-right font-semibold px-4 py-3">#</th>
                  <th className="text-right font-semibold px-4 py-3">المستخدم</th>
                  <th className="text-right font-semibold px-4 py-3">النقاط</th>
                  <th className="text-right font-semibold px-4 py-3">الطريقة</th>
                  <th className="text-right font-semibold px-4 py-3">الوجهة</th>
                  <th className="text-right font-semibold px-4 py-3">الحالة</th>
                  <th className="text-right font-semibold px-4 py-3">التاريخ</th>
                  <th className="text-right font-semibold px-4 py-3"></th>
                </tr>
              </thead>
              <tbody>
                {withdrawals.map((w) => (
                  <tr key={w.withdrawal_id} className="border-b border-white/[0.04] hover:bg-white/[0.02]">
                    <td className="px-4 py-3 num text-muted-foreground text-xs">{w.withdrawal_id}</td>
                    <td className="px-4 py-3">
                      <div className="font-semibold text-xs">{displayName(w.users)}</div>
                      <div className="text-[11px] text-muted-foreground num">{w.users?.telegram_id}</div>
                    </td>
                    <td className="px-4 py-3 num font-bold text-amber-300">{formatNumber(w.amount)}</td>
                    <td className="px-4 py-3 text-xs">{w.method}</td>
                    <td className="px-4 py-3 text-xs num text-muted-foreground max-w-[140px] truncate" dir="ltr">{w.destination}</td>
                    <td className="px-4 py-3"><StatusBadge status={w.status} /></td>
                    <td className="px-4 py-3 text-[11px] text-muted-foreground whitespace-nowrap">{formatDate(w.created_at)}</td>
                    <td className="px-4 py-3">
                      <Button size="sm" variant="outline" className="border-white/10 gap-1.5 h-8" onClick={() => { setSelected(w); setNote('') }}>
                        <Eye className="h-3.5 w-3.5" /> فتح
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <Dialog open={!!selected} onOpenChange={(open) => !open && setSelected(null)}>
        <DialogContent className="bg-[hsl(220,24%,7%)] border-white/10 text-foreground max-w-lg">
          <DialogHeader>
            <DialogTitle>طلب سحب #{selected?.withdrawal_id}</DialogTitle>
          </DialogHeader>
          {selected && (
            <div className="space-y-4 pt-1">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <Info label="المستخدم" value={displayName(selected.users)} />
                <Info label="Telegram ID" value={String(selected.users?.telegram_id ?? '—')} num />
                <Info label="النقاط" value={formatNumber(selected.amount)} num gold />
                <Info label="رصيد المستخدم الحالي" value={formatNumber(selected.users?.points ?? 0)} num />
                <Info label="الطريقة" value={selected.method} />
                <Info label="الوجهة / المحفظة" value={selected.destination} num />
                <Info label="الحالة" value={<StatusBadge status={selected.status} />} />
                <Info label="تاريخ الطلب" value={formatDate(selected.created_at)} />
                {selected.processed_at && <Info label="عولج في" value={formatDate(selected.processed_at)} />}
                {selected.admin_note && <Info label="ملاحظة" value={selected.admin_note} />}
              </div>

              {canProcess && !['rejected', 'completed'].includes(selected.status) && (
                <>
                  <Textarea placeholder="ملاحظة إدارية (اختياري)…" value={note} onChange={(e) => setNote(e.target.value)}
                    className="bg-white/[0.03] border-white/10 min-h-[70px]" />
                  <div className="grid grid-cols-2 gap-2">
                    {selected.status === 'pending' && (
                      <Button disabled={actionLoading} onClick={() => process('processing')} variant="outline" className="border-sky-400/30 text-sky-300 gap-1.5">
                        <Clock className="h-4 w-4" /> قيد المعالجة
                      </Button>
                    )}
                    {(selected.status === 'pending' || selected.status === 'processing') && (
                      <Button disabled={actionLoading} onClick={() => process('approve')} className="bg-emerald-500/90 hover:bg-emerald-400 text-emerald-950 font-bold gap-1.5">
                        <CheckCircle2 className="h-4 w-4" /> قبول
                      </Button>
                    )}
                    {(selected.status === 'approved' || selected.status === 'processing') && (
                      <Button disabled={actionLoading} onClick={() => process('complete')} className="bg-amber-400 hover:bg-amber-300 text-amber-950 font-bold gap-1.5">
                        <CheckCircle2 className="h-4 w-4" /> إتمام الدفع
                      </Button>
                    )}
                    <Button disabled={actionLoading} onClick={() => process('reject')} variant="outline" className="border-red-400/30 text-red-400 gap-1.5">
                      {actionLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <XCircle className="h-4 w-4" />} رفض + إرجاع النقاط
                    </Button>
                  </div>
                  <p className="text-[11px] text-muted-foreground">عند الرفض تُعاد النقاط للمستخدم تلقائياً عبر معاملة reversal موثقة، دون حذف أي سجل.</p>
                </>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function Info({ label, value, num, gold }: { label: string; value: React.ReactNode; num?: boolean; gold?: boolean }) {
  return (
    <div className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-3">
      <p className="text-[11px] text-muted-foreground">{label}</p>
      <p className={cn('mt-1 font-bold text-sm', num && 'num', gold && 'text-amber-300')}>{value}</p>
    </div>
  )
}
