import { useCallback, useEffect, useState } from 'react'
import { Settings as SettingsIcon, Loader2, Save } from 'lucide-react'
import { settingsService } from '@/services/settingsService'
import { LoadingState, ErrorState, PageHeader } from '@/components/States'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { useAuth } from '@/hooks/useAuth'

interface SettingField {
  key: string
  label: string
  type: 'text' | 'number' | 'boolean'
  hint?: string
}

const fields: SettingField[] = [
  { key: 'bot_username', label: 'معرّف البوت', type: 'text' },
  { key: 'mandatory_channel', label: 'القناة الإجبارية', type: 'text' },
  { key: 'mandatory_channel_url', label: 'رابط القناة الإجبارية', type: 'text' },
  { key: 'timezone', label: 'المنطقة الزمنية', type: 'text', hint: 'مثال: Africa/Algiers' },
  { key: 'daily_day_1', label: 'مكافأة اليوم الأول', type: 'number' },
  { key: 'referral_reward', label: 'مكافأة الإحالة (نقاط)', type: 'number' },
  { key: 'minimum_withdrawal', label: 'الحد الأدنى للسحب', type: 'number' },
  { key: 'max_earn_per_hour', label: 'أقصى ربح بالساعة', type: 'number' },
  { key: 'ads_enabled', label: 'تفعيل الإعلانات', type: 'boolean' },
  { key: 'wheel_enabled', label: 'تفعيل عجلة الحظ', type: 'boolean' },
  { key: 'withdrawal_enabled', label: 'تفعيل السحب', type: 'boolean' },
  { key: 'maintenance_mode', label: 'وضع الصيانة', type: 'boolean', hint: 'يوقف البوت مؤقتاً عن الاستجابة' },
  { key: 'leaderboard_enabled', label: 'تفعيل المتصدرين', type: 'boolean' },
  { key: 'notifications_enabled', label: 'تفعيل الإشعارات', type: 'boolean' },
]

export default function SettingsPage() {
  const { admin } = useAuth()
  const isOwner = admin?.role === 'OWNER'
  const [settings, setSettings] = useState<Record<string, unknown>>({})
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)
  const [saving, setSaving] = useState<string | null>(null)
  const [toast, setToast] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      setSettings(await settingsService.getAll())
    } catch (e) {
      console.error(e)
      setError(true)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  const notify = (msg: string) => { setToast(msg); setTimeout(() => setToast(null), 3000) }

  const save = async (key: string, value: unknown) => {
    setSaving(key)
    try {
      await settingsService.update(key, value)
      notify('تم حفظ الإعداد')
      await load()
    } catch (e) {
      console.error(e)
      notify('فشل الحفظ — هذا الإعداد يتطلب صلاحية المالك')
    } finally {
      setSaving(null)
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader title="إعدادات النظام" subtitle="الإعدادات الحساسة متاحة للمالك فقط — لا يمكن تغيير الأسرار (Secrets) من هنا" />

      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 rounded-xl border border-amber-400/30 bg-[hsl(220,24%,8%)] px-5 py-3 text-sm font-bold shadow-2xl animate-slide-up">{toast}</div>
      )}

      {!isOwner && (
        <div className="rounded-xl border border-orange-400/25 bg-orange-400/10 px-4 py-3 text-sm text-orange-200">
          معظم الإعدادات تتطلب صلاحية المالك (OWNER). يمكنك تعديل إعدادات الإعلانات والعجلة فقط.
        </div>
      )}

      {error ? <ErrorState onRetry={load} /> : loading ? <LoadingState /> : (
        <div className="grid md:grid-cols-2 gap-3">
          {fields.map((f) => (
            <div key={f.key} className="glass-card p-4 flex items-center justify-between gap-4">
              <div className="min-w-0">
                <p className="text-sm font-bold">{f.label}</p>
                <p className="text-[11px] text-muted-foreground num" dir="ltr">{f.key}</p>
                {f.hint && <p className="text-[11px] text-muted-foreground mt-0.5">{f.hint}</p>}
              </div>
              {f.type === 'boolean' ? (
                <Switch
                  checked={settings[f.key] === true}
                  disabled={saving === f.key}
                  onCheckedChange={(v) => save(f.key, v)}
                />
              ) : (
                <SettingInput
                  type={f.type}
                  value={settings[f.key]}
                  saving={saving === f.key}
                  onSave={(v) => save(f.key, f.type === 'number' ? Number(v) : v)}
                />
              )}
            </div>
          ))}
        </div>
      )}

      <div className="glass-card p-5">
        <div className="flex items-center gap-3 mb-3">
          <SettingsIcon className="h-5 w-5 text-amber-400" />
          <h3 className="font-bold">Webhooks الجاهزة لـ n8n</h3>
        </div>
        <div className="grid md:grid-cols-2 gap-2 text-xs" dir="ltr">
          {['/api/webhooks/telegram', '/api/webhooks/broadcast', '/api/webhooks/ad-verification', '/api/webhooks/withdrawal'].map((w) => (
            <code key={w} className="rounded-lg border border-white/[0.08] bg-white/[0.03] px-3 py-2 text-amber-200/80">{w}</code>
          ))}
        </div>
        <p className="text-[11px] text-muted-foreground mt-3">رمز البوت (Bot Token) ومفاتيح service_role تُدار في n8n / Supabase فقط ولا تظهر هنا أبداً.</p>
      </div>
    </div>
  )
}

function SettingInput({ type, value, saving, onSave }: { type: 'text' | 'number'; value: unknown; saving: boolean; onSave: (v: string) => void }) {
  const [val, setVal] = useState(String(value ?? ''))
  const dirty = val !== String(value ?? '')
  return (
    <div className="flex items-center gap-2 shrink-0">
      <Input
        type={type}
        dir="ltr"
        value={val}
        onChange={(e) => setVal(e.target.value)}
        className="w-36 bg-white/[0.03] border-white/10 text-left h-9 text-sm"
      />
      {dirty && (
        <Button size="icon" disabled={saving} onClick={() => onSave(val)}
          className="h-9 w-9 bg-amber-400 text-amber-950 hover:bg-amber-300">
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
        </Button>
      )}
    </div>
  )
}
