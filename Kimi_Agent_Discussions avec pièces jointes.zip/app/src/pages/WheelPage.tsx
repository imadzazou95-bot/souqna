import { useCallback, useEffect, useState } from 'react'
import { Disc3, Loader2 } from 'lucide-react'
import { wheelService, settingsService } from '@/services/settingsService'
import { EmptyState } from '@/components/EmptyState'
import { LoadingState, ErrorState, PageHeader } from '@/components/States'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { useAuth } from '@/hooks/useAuth'
import type { WheelSpin } from '@/types'
import { formatNumber, timeAgo } from '@/utils/format'

export default function WheelPage() {
  const { admin } = useAuth()
  const canEdit = admin?.role === 'OWNER' || admin?.role === 'ADMIN'
  const [stats, setStats] = useState<{ total: number; recent: WheelSpin[]; bySegment: Record<number, number> } | null>(null)
  const [config, setConfig] = useState<{ enabled: boolean; maxDailySpins: number; minBalance: number; rewards: number[] } | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)
  const [saving, setSaving] = useState(false)
  const [toast, setToast] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      const [s, settings] = await Promise.all([wheelService.getStats(), settingsService.getAll()])
      setStats(s)
      setConfig(await wheelService.getConfig(settings))
    } catch (e) {
      console.error(e)
      setError(true)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  const notify = (msg: string) => { setToast(msg); setTimeout(() => setToast(null), 3000) }

  const save = async () => {
    if (!config) return
    setSaving(true)
    try {
      await settingsService.update('wheel_enabled', config.enabled)
      await settingsService.update('wheel_max_daily_spins', config.maxDailySpins)
      await settingsService.update('wheel_min_balance', config.minBalance)
      for (let i = 0; i < 8; i++) {
        await settingsService.update(`wheel_reward_${i + 1}`, config.rewards[i])
      }
      notify('تم حفظ إعدادات العجلة')
      await load()
    } catch (e) {
      console.error(e)
      notify('حدث خطأ — قد تحتاج صلاحية المالك')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader title="عجلة الحظ" subtitle="نتيجة اللفة تُحدَّد على الخادم (spin_wheel RPC) — لا يمكن التلاعب بها من المتصفح" />

      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 rounded-xl border border-amber-400/30 bg-[hsl(220,24%,8%)] px-5 py-3 text-sm font-bold shadow-2xl animate-slide-up">{toast}</div>
      )}

      {error ? <ErrorState onRetry={load} /> : loading ? <LoadingState /> : stats && config && (
        <div className="grid lg:grid-cols-2 gap-4">
          <div className="space-y-4">
            <div className="glass-card p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold">إعدادات العجلة</h3>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">{config.enabled ? 'مفعّلة' : 'معطّلة'}</span>
                  <Switch checked={config.enabled} disabled={!canEdit}
                    onCheckedChange={(v) => setConfig({ ...config, enabled: v })} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div>
                  <label className="text-xs text-muted-foreground">أقصى لفات يومياً</label>
                  <Input type="number" dir="ltr" disabled={!canEdit} value={config.maxDailySpins}
                    onChange={(e) => setConfig({ ...config, maxDailySpins: Number(e.target.value) })}
                    className="mt-1 bg-white/[0.03] border-white/10 text-left" />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">أقل رصيد للّف</label>
                  <Input type="number" dir="ltr" disabled={!canEdit} value={config.minBalance}
                    onChange={(e) => setConfig({ ...config, minBalance: Number(e.target.value) })}
                    className="mt-1 bg-white/[0.03] border-white/10 text-left" />
                </div>
              </div>
              <h4 className="text-sm font-bold mb-2">جوائز القطاعات الثمانية</h4>
              <div className="grid grid-cols-4 gap-2">
                {config.rewards.map((r, i) => (
                  <div key={i}>
                    <label className="text-[10px] text-muted-foreground">قطاع {i + 1}</label>
                    <Input type="number" dir="ltr" disabled={!canEdit} value={r}
                      onChange={(e) => {
                        const rewards = [...config.rewards]
                        rewards[i] = Number(e.target.value)
                        setConfig({ ...config, rewards })
                      }}
                      className="mt-1 bg-white/[0.03] border-white/10 text-left text-amber-300 font-bold" />
                  </div>
                ))}
              </div>
              {canEdit && (
                <Button onClick={save} disabled={saving} className="w-full mt-4 bg-amber-400 text-amber-950 hover:bg-amber-300 font-bold">
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'حفظ الإعدادات'}
                </Button>
              )}
            </div>

            <div className="glass-card p-5 text-center">
              <p className="text-3xl font-extrabold num">{formatNumber(stats.total)}</p>
              <p className="text-xs text-muted-foreground mt-1">إجمالي اللفات</p>
            </div>
          </div>

          <div className="glass-card p-5">
            <h3 className="font-bold mb-4">آخر اللفات</h3>
            {stats.recent.length === 0 ? (
              <EmptyState icon={Disc3} title="لا توجد لفات بعد" description="ستظهر نتائج العجلة هنا فور بدء المستخدمين باللّف" />
            ) : (
              <div className="space-y-2 max-h-[420px] overflow-y-auto">
                {stats.recent.map((s) => (
                  <div key={s.wheel_spin_id} className="flex items-center justify-between rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-2.5 text-sm">
                    <span className="num text-muted-foreground">{s.user_id}</span>
                    <span className="text-xs text-muted-foreground">قطاع <span className="num">{s.segment}</span></span>
                    <span className="num font-bold text-emerald-400">+{formatNumber(s.reward)}</span>
                    <span className="text-[11px] text-muted-foreground">{timeAgo(s.created_at)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
