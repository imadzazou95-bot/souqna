import { useState } from 'react'
import { useNavigate } from 'react-router'
import { Coins, Loader2, Lock, Mail } from 'lucide-react'
import { useAuth } from '@/hooks/useAuth'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

export default function LoginPage() {
  const { signIn } = useAuth()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    try {
      await signIn(email.trim(), password)
      navigate('/')
    } catch (err) {
      console.error(err)
      setError(
        (err as Error).message === 'not_authorized'
          ? 'هذا الحساب غير مصرّح له بالدخول إلى لوحة التحكم'
          : 'بيانات الدخول غير صحيحة، حاول مرة أخرى'
      )
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 right-1/4 h-72 w-72 rounded-full bg-amber-500/[0.07] blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 h-72 w-72 rounded-full bg-amber-600/[0.05] blur-3xl" />
      </div>

      <div className="w-full max-w-md animate-slide-up relative">
        <div className="glass-card p-8 md:p-10">
          <div className="flex flex-col items-center mb-8">
            <div className="rounded-2xl bg-gradient-to-br from-amber-300 to-amber-600 p-3.5 gold-glow mb-4">
              <Coins className="h-9 w-9 text-amber-950" />
            </div>
            <h1 className="text-2xl font-extrabold gold-text">TFARAJ Rewards</h1>
            <p className="text-sm text-muted-foreground mt-1">لوحة تحكم المشرفين</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="relative">
              <Mail className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="email"
                placeholder="البريد الإلكتروني"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                dir="ltr"
                className="pr-10 text-left bg-white/[0.03] border-white/10 h-12"
              />
            </div>
            <div className="relative">
              <Lock className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="password"
                placeholder="كلمة المرور"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                dir="ltr"
                className="pr-10 text-left bg-white/[0.03] border-white/10 h-12"
              />
            </div>

            {error && (
              <div className="rounded-xl border border-red-400/25 bg-red-400/10 px-4 py-3 text-sm text-red-300">
                {error}
              </div>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="w-full h-12 bg-amber-400 text-amber-950 hover:bg-amber-300 font-extrabold text-base gold-glow"
            >
              {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : 'تسجيل الدخول'}
            </Button>
          </form>

          <p className="mt-6 text-center text-xs text-muted-foreground">
            الدخول متاح للمشرفين المسجلين فقط · محمي عبر Supabase Auth + RLS
          </p>
        </div>
      </div>
    </div>
  )
}
