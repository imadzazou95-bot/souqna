import { useCallback, useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router'
import {
  ArrowRight, Ban, ShieldAlert, Snowflake, Coins, PlusCircle, MinusCircle,
  BadgeCheck, BadgeX, Loader2,
} from 'lucide-react'
import { userService } from '@/services/userService'
import { StatusBadge } from '@/components/StatusBadge'
import { LoadingState, ErrorState } from '@/components/States'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { useAuth } from '@/hooks/useAuth'
import type { BotUser } from '@/types'
import { formatDate, formatNumber } from '@/utils/format'
import { cn } from '@/lib/utils'

type Tab = 'transactions' | 'referrals' | 'ads' | 'daily' | 'spins' | 'withdrawals' | 'security'

const tabs: { key: Tab; label: string }[] = [
  { key: 'transactions', label: 'النقاط' },
  { key: 'referrals', label: 'الإحالات' },
  { key: 'ads', label: 'الإعلانات' },
  { key: 'daily', label: 'اليومية' },
  { key: 'spins', label: 'العجلة' },
  { key: 'withdrawals', label: 'السحوبات' },
  { key: 'security', label: 'الأمان' },
]

export default function UserDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { admin } = useAuth()
  const canEdit = admin?.role === 'OWNER' || admin?.role === 'ADMIN'

  const [user, setUser] = useState<BotUser | null>(null)
  const [activity, setActivity] = useState<Awaited<ReturnType<typeof userService.getUserActivity>> | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)
  const [tab, setTab] = useState<Tab>('transactions')
  const [adjustOpen, setAdjustOpen] = useState(false)
  const [adjustAmount, setAdjustAmount] = useState('')
  const [adjustNote, setAdjustNote] = useState('')
  const [actionLoading, setActionLoading] = useState(false)
  const [toast, setToast] = useState<string | null>(null)

  const load = useCallback(async () => {
    if (!id) return
    setLoading(true)
    setError(false)
    try {
      const u = await userService.getById(Number(id))
      setUser(u)
      if (u) setActivity(await userService.getUserActivity(u.id))
    } catch (e) {
      console.error(e)
      setError(true)
    } finally {
      setLoading(false)
    }
  }, [id])

  useEffect(() => { load() }, [load])

  const doAction = async (fn: () => Promise<unknown>, msg: string) => {
    setActionLoading(true)
    try {
      await fn()
      setToast(msg)
      await load()
    } catch (e) {
      console.error(e)
      setToast('حدث خطأ، حاول مرة أخرى')
    } finally {
      setActionLoading(false)
      setTimeout(() => setToast(null), 3000)
    }
  }

  if (loading) return <LoadingState />
  if (error || !user) return <ErrorState onRetry={load} />

  const name = [user.first_name, user.last_name].filter(Boolean).join(' ') || '—'

  return (
    <div className="space-y-5">
      <button onClick={() => navigate('/users')} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-amber-300 transition-colors">
        <ArrowRight className="h-4 w-4" /> العودة للمستخدمين
      </button>

      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 rounded-xl border border-amber-400/30 bg-[hsl(220,24%,8%)] px-5 py-3 text-sm font-bold shadow-2xl animate-slide-up">
          {toast}
        </div>
      )}

      {/* Profile card */}
      <div className="glass-card p-6 animate-slide-up">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-amber-400/20 to-amber-600/10 border border-amber-400/20 flex items-center justify-center text-2xl font-extrabold text-amber-300">
              {name[0] ?? '؟'}
            </div>
            <div>
              <h1 className="text-xl font-extrabold">{name}</h1>
              <p className="text-sm text-muted-foreground num">{user.username ? `@${user.username} · ` : ''}{user.telegram_id}</p>
              <div className="flex flex-wrap gap-2 mt-2">
                <StatusBadge status={user.is_banned ? 'banned' : user.is_suspicious ? 'suspicious' : user.status} />
                {user.is_channel_member
                  ? <span className="inline-flex items-center gap-1 text-xs text-emerald-400"><BadgeCheck className="h-3.5 w-3.5" /> مشترك بالقناة</span>
                  : <span className="inline-flex items-center gap-1 text-xs text-muted-foreground"><BadgeX className="h-3.5 w-3.5" /> غير مشترك</span>}
                {user.rewards_frozen && <StatusBadge status="frozen" label="مكافآت مجمّدة" />}
              </div>
            </div>
          </div>
          {canEdit && (
            <div className="flex flex-wrap gap-2">
              <Button size="sm" onClick={() => setAdjustOpen(true)} className="bg-amber-400 text-amber-950 hover:bg-amber-300 font-bold gap-1.5">
                <Coins className="h-4 w-4" /> تعديل الرصيد
              </Button>
              <Button size="sm" variant="outline" disabled={actionLoading}
                onClick={() => doAction(() => userService.setStatus(user.id, { is_banned: !user.is_banned, status: !user.is_banned ? 'banned' : 'active' }), user.is_banned ? 'تم فك الحظر' : 'تم حظر المستخدم')}
                className={cn('gap-1.5 border-white/10', user.is_banned ? 'text-emerald-400' : 'text-red-400')}>
                <Ban className="h-4 w-4" /> {user.is_banned ? 'فك الحظر' : 'حظر'}
              </Button>
              <Button size="sm" variant="outline" disabled={actionLoading}
                onClick={() => doAction(() => userService.setStatus(user.id, { is_suspicious: !user.is_suspicious }), 'تم تحديث حالة الاشتباه')}
                className="gap-1.5 border-white/10 text-orange-400">
                <ShieldAlert className="h-4 w-4" /> {user.is_suspicious ? 'إزالة الاشتباه' : 'اشتباه'}
              </Button>
              <Button size="sm" variant="outline" disabled={actionLoading}
                onClick={() => doAction(() => userService.setStatus(user.id, { rewards_frozen: !user.rewards_frozen }), user.rewards_frozen ? 'تم إلغاء التجميد' : 'تم تجميد المكافآت')}
                className="gap-1.5 border-white/10 text-violet-300">
                <Snowflake className="h-4 w-4" /> {user.rewards_frozen ? 'إلغاء التجميد' : 'تجميد المكافآت'}
              </Button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-6">
          {[
            { label: 'الرصيد الحالي', value: user.points, gold: true },
            { label: 'إجمالي الأرباح', value: user.total_points_earned },
            { label: 'إجمالي المسحوب', value: user.total_withdrawn },
            { label: 'الإحالات', value: user.referral_count },
            { label: 'إعلانات مشاهدة', value: user.total_ads_watched },
            { label: 'سلسلة اليومية', value: user.daily_streak },
            { label: 'المستوى', value: user.level },
            { label: 'مسجل منذ', value: formatDate(user.created_at), text: true },
          ].map((s) => (
            <div key={s.label} className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-3.5">
              <p className="text-[11px] text-muted-foreground">{s.label}</p>
              <p className={cn('mt-1 font-extrabold', s.text ? 'text-xs' : 'text-lg num', s.gold && 'text-amber-300')}>
                {typeof s.value === 'number' ? formatNumber(s.value) : s.value}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {tabs.map((t) => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={cn('whitespace-nowrap rounded-full px-4 py-1.5 text-xs font-bold border transition-all',
              tab === t.key ? 'bg-amber-400/15 text-amber-300 border-amber-400/30' : 'text-muted-foreground border-white/10 hover:bg-white/5')}>
            {t.label}
          </button>
        ))}
      </div>

      <div className="glass-card p-4 md:p-5 min-h-[200px]">
        {!activity ? <LoadingState /> : (
          <>
            {tab === 'transactions' && (
              <HistoryTable
                empty="لا توجد عمليات نقاط بعد"
                rows={activity.transactions.map((t) => [
                  <span className={cn('num font-bold', t.amount > 0 ? 'text-emerald-400' : 'text-red-400')}>
                    {t.amount > 0 ? '+' : ''}{formatNumber(t.amount)}
                  </span>,
                  t.type, t.description ?? '—', formatDate(t.created_at),
                ])}
                headers={['المبلغ', 'النوع', 'الوصف', 'التاريخ']}
              />
            )}
            {tab === 'referrals' && (
              <HistoryTable
                empty="لا توجد إحالات"
                rows={activity.referralsMade.map((r) => [
                  <span className="num">{r.invited_id}</span>,
                  <StatusBadge status={r.status} />,
                  <span className="num">{formatNumber(r.reward)}</span>,
                  formatDate(r.created_at),
                ])}
                headers={['المُحال', 'الحالة', 'المكافأة', 'التاريخ']}
              />
            )}
            {tab === 'ads' && (
              <HistoryTable
                empty="لم يشاهد إعلانات بعد"
                rows={activity.ads.map((a) => [
                  a.ad_tasks?.title ?? `إعلان #${a.ad_task_id}`,
                  <StatusBadge status={a.status} />,
                  formatDate(a.started_at),
                ])}
                headers={['الإعلان', 'الحالة', 'التاريخ']}
              />
            )}
            {tab === 'daily' && (
              <HistoryTable
                empty="لا توجد مكافآت يومية"
                rows={activity.daily.map((d) => [
                  <span className="num">{d.claim_date}</span>,
                  <span className="num">يوم {d.streak_day}</span>,
                  <span className="num text-emerald-400 font-bold">+{formatNumber(d.reward)}</span>,
                ])}
                headers={['التاريخ', 'السلسلة', 'المكافأة']}
              />
            )}
            {tab === 'spins' && (
              <HistoryTable
                empty="لا توجد لفات"
                rows={activity.spins.map((s) => [
                  <span className="num">قطاع {s.segment}</span>,
                  <span className="num text-emerald-400 font-bold">+{formatNumber(s.reward)}</span>,
                  formatDate(s.created_at),
                ])}
                headers={['القطاع', 'الجائزة', 'التاريخ']}
              />
            )}
            {tab === 'withdrawals' && (
              <HistoryTable
                empty="لا توجد طلبات سحب"
                rows={activity.withdrawals.map((w) => [
                  <span className="num font-bold">{formatNumber(w.amount)}</span>,
                  w.method, <StatusBadge status={w.status} />, formatDate(w.created_at),
                ])}
                headers={['المبلغ', 'الطريقة', 'الحالة', 'التاريخ']}
              />
            )}
            {tab === 'security' && (
              <HistoryTable
                empty="لا توجد أحداث مشبوهة لهذا المستخدم"
                rows={activity.suspicious.map((s) => [
                  s.reason,
                  <span className="num">{s.severity}/5</span>,
                  s.reviewed ? <StatusBadge status="done" label="تمت المراجعة" /> : <StatusBadge status="pending" label="قيد المراجعة" />,
                  formatDate(s.created_at),
                ])}
                headers={['السبب', 'الخطورة', 'الحالة', 'التاريخ']}
              />
            )}
          </>
        )}
      </div>

      {/* Adjust balance dialog */}
      <Dialog open={adjustOpen} onOpenChange={setAdjustOpen}>
        <DialogContent className="bg-[hsl(220,24%,7%)] border-white/10 text-foreground">
          <DialogHeader>
            <DialogTitle>تعديل رصيد {name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <p className="text-sm text-muted-foreground">الرصيد الحالي: <span className="num font-bold text-amber-300">{formatNumber(user.points)}</span> نقطة</p>
            <Input type="number" dir="ltr" placeholder="المبلغ (موجب للإضافة، سالب للخصم)" value={adjustAmount}
              onChange={(e) => setAdjustAmount(e.target.value)} className="bg-white/[0.03] border-white/10 text-left" />
            <Input placeholder="سبب التعديل (اختياري)" value={adjustNote}
              onChange={(e) => setAdjustNote(e.target.value)} className="bg-white/[0.03] border-white/10" />
            <div className="flex gap-2">
              <Button disabled={actionLoading || !adjustAmount || Number(adjustAmount) === 0}
                onClick={() => doAction(async () => {
                  await userService.adjustBalance(user.id, Number(adjustAmount), adjustNote || undefined)
                  setAdjustOpen(false); setAdjustAmount(''); setAdjustNote('')
                }, 'تم تعديل الرصيد بنجاح')}
                className="flex-1 bg-amber-400 text-amber-950 hover:bg-amber-300 font-bold gap-2">
                {actionLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : Number(adjustAmount) >= 0 ? <PlusCircle className="h-4 w-4" /> : <MinusCircle className="h-4 w-4" />}
                تأكيد التعديل
              </Button>
              <Button variant="outline" onClick={() => setAdjustOpen(false)} className="border-white/10">إلغاء</Button>
            </div>
            <p className="text-[11px] text-muted-foreground">يتم التعديل عبر دالة آمنة في قاعدة البيانات وتُسجّل في سجل الإجراءات.</p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function HistoryTable({ headers, rows, empty }: { headers: string[]; rows: React.ReactNode[][]; empty: string }) {
  if (rows.length === 0) {
    return <p className="py-10 text-center text-sm text-muted-foreground">{empty}</p>
  }
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-white/[0.06] text-muted-foreground text-xs">
            {headers.map((h) => <th key={h} className="text-right font-semibold px-3 py-2.5">{h}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.map((cells, i) => (
            <tr key={i} className="border-b border-white/[0.04]">
              {cells.map((c, j) => <td key={j} className="px-3 py-2.5">{c}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
