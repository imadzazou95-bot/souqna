import { useCallback, useEffect, useState } from 'react'
import { Megaphone, Plus, Loader2 } from 'lucide-react'
import { adsService } from '@/services/adsService'
import { StatusBadge } from '@/components/StatusBadge'
import { EmptyState } from '@/components/EmptyState'
import { LoadingState, ErrorState, PageHeader } from '@/components/States'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import type { AdProvider, AdTask } from '@/types'
import { formatNumber } from '@/utils/format'
import { cn } from '@/lib/utils'

export default function AdsPage() {
  const [tasks, setTasks] = useState<AdTask[]>([])
  const [providers, setProviders] = useState<AdProvider[]>([])
  const [sessionStats, setSessionStats] = useState<{ total: number; started: number; completed: number; expired: number; rejected: number } | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)
  const [createOpen, setCreateOpen] = useState(false)
  const [form, setForm] = useState({ code: '', title: '', reward: '10', daily_limit: '' })
  const [saving, setSaving] = useState(false)
  const [toast, setToast] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      const [t, p, s] = await Promise.all([adsService.listTasks(), adsService.listProviders(), adsService.getSessionStats()])
      setTasks(t)
      setProviders(p)
      setSessionStats(s)
    } catch (e) {
      console.error(e)
      setError(true)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  const notify = (msg: string) => { setToast(msg); setTimeout(() => setToast(null), 3000) }

  const create = async () => {
    setSaving(true)
    try {
      await adsService.createTask({
        code: form.code.trim(),
        title: form.title.trim(),
        reward: Number(form.reward),
        daily_limit: form.daily_limit ? Number(form.daily_limit) : null,
        provider_id: providers[0]?.id ?? null,
      })
      setCreateOpen(false)
      setForm({ code: '', title: '', reward: '10', daily_limit: '' })
      notify('تم إنشاء الإعلان')
      await load()
    } catch (e) {
      console.error(e)
      notify('حدث خطأ، حاول مرة أخرى')
    } finally {
      setSaving(false)
    }
  }

  const toggleTask = async (t: AdTask) => {
    try {
      await adsService.toggleTask(t.id, !t.is_active)
      notify(t.is_active ? 'تم تعطيل الإعلان' : 'تم تفعيل الإعلان')
      await load()
    } catch (e) { console.error(e); notify('حدث خطأ') }
  }

  if (error) return <ErrorState onRetry={load} />

  return (
    <div className="space-y-5">
      <PageHeader title="إدارة الإعلانات" subtitle="مكافآت الإعلانات تُمنح فقط بعد التحقق من الجلسة (session_token) على الخادم"
        actions={<Button onClick={() => setCreateOpen(true)} className="bg-amber-400 text-amber-950 hover:bg-amber-300 font-bold gap-1.5">
          <Plus className="h-4 w-4" /> إعلان جديد
        </Button>} />

      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 rounded-xl border border-amber-400/30 bg-[hsl(220,24%,8%)] px-5 py-3 text-sm font-bold shadow-2xl animate-slide-up">
          {toast}
        </div>
      )}

      {sessionStats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'جلسات مكتملة', value: sessionStats.completed, cls: 'text-emerald-300' },
            { label: 'قيد المشاهدة', value: sessionStats.started, cls: 'text-sky-300' },
            { label: 'منتهية الصلاحية', value: sessionStats.expired, cls: 'text-muted-foreground' },
            { label: 'مرفوضة', value: sessionStats.rejected, cls: 'text-red-300' },
          ].map((s) => (
            <div key={s.label} className="glass-card p-4 text-center">
              <p className={cn('text-2xl font-extrabold num', s.cls)}>{formatNumber(s.value)}</p>
              <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      )}

      {loading ? <LoadingState /> : tasks.length === 0 ? (
        <EmptyState icon={Megaphone} title="لا توجد إعلانات" description="أنشئ أول إعلان ليظهر في البوت" actionLabel="إعلان جديد" onAction={() => setCreateOpen(true)} />
      ) : (
        <div className="grid md:grid-cols-2 gap-3">
          {tasks.map((t) => (
            <div key={t.id} className="glass-card p-5 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-bold">{t.title ?? t.code}</h3>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {t.ad_providers?.name ?? 'بدون مزود'} · <span className="num">{t.code}</span>
                  </p>
                </div>
                <StatusBadge status={t.is_active ? 'active' : 'paused'} label={t.is_active ? 'مفعّل' : 'معطّل'} />
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground text-xs">المكافأة: <span className="num font-bold text-amber-300">{formatNumber(t.reward)}</span> نقطة</span>
                <span className="text-muted-foreground text-xs">الحد اليومي: <span className="num">{t.daily_limit ?? '∞'}</span></span>
              </div>
              <div className="flex items-center justify-between border-t border-white/[0.06] pt-3">
                <span className="text-xs text-muted-foreground">{t.is_active ? 'إيقاف الإعلان' : 'تفعيل الإعلان'}</span>
                <Switch checked={t.is_active} onCheckedChange={() => toggleTask(t)} />
              </div>
            </div>
          ))}
        </div>
      )}

      {providers.length > 0 && (
        <div className="glass-card p-5">
          <h3 className="font-bold mb-3">مزودو الإعلانات</h3>
          <div className="space-y-2">
            {providers.map((p) => (
              <div key={p.id} className="flex items-center justify-between rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3">
                <span className="text-sm font-semibold">{p.name}</span>
                <StatusBadge status={p.is_active ? 'active' : 'paused'} label={p.is_active ? 'مفعّل' : 'معطّل'} />
              </div>
            ))}
          </div>
        </div>
      )}

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="bg-[hsl(220,24%,7%)] border-white/10 text-foreground">
          <DialogHeader><DialogTitle>إعلان جديد</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <Input placeholder="العنوان" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="bg-white/[0.03] border-white/10" />
            <Input placeholder="الكود (مثال: ad_watch_1)" dir="ltr" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} className="bg-white/[0.03] border-white/10 text-left" />
            <div className="grid grid-cols-2 gap-3">
              <Input placeholder="المكافأة (نقاط)" type="number" dir="ltr" value={form.reward} onChange={(e) => setForm({ ...form, reward: e.target.value })} className="bg-white/[0.03] border-white/10 text-left" />
              <Input placeholder="الحد اليومي (اختياري)" type="number" dir="ltr" value={form.daily_limit} onChange={(e) => setForm({ ...form, daily_limit: e.target.value })} className="bg-white/[0.03] border-white/10 text-left" />
            </div>
            <Button onClick={create} disabled={saving || !form.code || !form.title} className="w-full bg-amber-400 text-amber-950 hover:bg-amber-300 font-bold">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'إنشاء'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
