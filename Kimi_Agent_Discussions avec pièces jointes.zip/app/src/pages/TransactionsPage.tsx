import { useCallback, useEffect, useState } from 'react'
import { ArrowLeftRight, ArrowUpCircle, ArrowDownCircle, ChevronRight, ChevronLeft } from 'lucide-react'
import { transactionService } from '@/services/transactionService'
import { EmptyState } from '@/components/EmptyState'
import { LoadingState, ErrorState, PageHeader } from '@/components/States'
import { Button } from '@/components/ui/button'
import type { Transaction, TransactionType } from '@/types'
import { formatDate, formatNumber } from '@/utils/format'
import { cn } from '@/lib/utils'

const PAGE_SIZE = 25

const typeLabels: Record<string, string> = {
  daily_bonus: 'مكافأة يومية', wheel_reward: 'عجلة الحظ', ad_reward: 'مكافأة إعلان',
  referral_reward: 'مكافأة إحالة', task_reward: 'مكافأة مهمة', withdrawal: 'سحب',
  admin_adjustment: 'تعديل إداري', bonus: 'مكافأة', penalty: 'خصم', promo_reward: 'برومو',
  signup_bonus: 'مكافأة تسجيل', reversal: 'استرجاع',
}

const typeTabs: { key: TransactionType | 'all'; label: string }[] = [
  { key: 'all', label: 'الكل' },
  { key: 'ad_reward', label: 'إعلانات' },
  { key: 'referral_reward', label: 'إحالات' },
  { key: 'daily_bonus', label: 'يومية' },
  { key: 'wheel_reward', label: 'عجلة' },
  { key: 'withdrawal', label: 'سحب' },
  { key: 'reversal', label: 'استرجاع' },
  { key: 'admin_adjustment', label: 'تعديل إداري' },
]

export default function TransactionsPage() {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(0)
  const [type, setType] = useState<TransactionType | 'all'>('all')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      const res = await transactionService.list({ type }, page, PAGE_SIZE)
      setTransactions(res.transactions)
      setTotal(res.total)
    } catch (e) {
      console.error(e)
      setError(true)
    } finally {
      setLoading(false)
    }
  }, [type, page])

  useEffect(() => { load() }, [load])

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE))

  return (
    <div className="space-y-5">
      <PageHeader title="سجل المعاملات" subtitle="كل عمليات النقاط قابلة للتتبع بالكامل (Ledger)" />

      <div className="flex gap-2 overflow-x-auto pb-1">
        {typeTabs.map((t) => (
          <button key={t.key} onClick={() => { setType(t.key); setPage(0) }}
            className={cn('whitespace-nowrap rounded-full px-4 py-1.5 text-xs font-bold border transition-all',
              type === t.key ? 'bg-amber-400/15 text-amber-300 border-amber-400/30' : 'text-muted-foreground border-white/10 hover:bg-white/5')}>
            {t.label}
          </button>
        ))}
      </div>

      {error ? <ErrorState onRetry={load} /> : loading ? <LoadingState /> : transactions.length === 0 ? (
        <EmptyState icon={ArrowLeftRight} title="لا توجد معاملات" description="ستظهر هنا كل عمليات النقاط فور حدوثها" />
      ) : (
        <>
          <div className="glass-card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/[0.06] text-muted-foreground text-xs">
                    <th className="text-right font-semibold px-4 py-3">#</th>
                    <th className="text-right font-semibold px-4 py-3">المستخدم</th>
                    <th className="text-right font-semibold px-4 py-3">النوع</th>
                    <th className="text-right font-semibold px-4 py-3">المبلغ</th>
                    <th className="text-right font-semibold px-4 py-3">الرصيد بعد</th>
                    <th className="text-right font-semibold px-4 py-3">المرجع</th>
                    <th className="text-right font-semibold px-4 py-3">الوصف</th>
                    <th className="text-right font-semibold px-4 py-3">التاريخ</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.map((t) => (
                    <tr key={t.id} className="border-b border-white/[0.04] hover:bg-white/[0.02]">
                      <td className="px-4 py-3 num text-muted-foreground text-xs">{t.id}</td>
                      <td className="px-4 py-3">
                        <div className="font-semibold text-xs">{t.users?.first_name ?? '—'}</div>
                        <div className="text-[11px] text-muted-foreground num">{t.users?.telegram_id}</div>
                      </td>
                      <td className="px-4 py-3 text-xs">{typeLabels[t.type] ?? t.type}</td>
                      <td className="px-4 py-3">
                        <span className={cn('inline-flex items-center gap-1 num font-bold',
                          t.amount > 0 ? 'text-emerald-400' : 'text-red-400')}>
                          {t.amount > 0 ? <ArrowUpCircle className="h-3.5 w-3.5" /> : <ArrowDownCircle className="h-3.5 w-3.5" />}
                          {t.amount > 0 ? '+' : ''}{formatNumber(t.amount)}
                        </span>
                      </td>
                      <td className="px-4 py-3 num text-muted-foreground">{formatNumber(t.balance_after)}</td>
                      <td className="px-4 py-3 num text-[11px] text-muted-foreground max-w-[140px] truncate" dir="ltr">{t.reference_id ?? '—'}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground max-w-[180px] truncate">{t.description ?? '—'}</td>
                      <td className="px-4 py-3 text-[11px] text-muted-foreground whitespace-nowrap">{formatDate(t.created_at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <p className="text-xs text-muted-foreground">صفحة <span className="num">{page + 1}</span> من <span className="num">{totalPages}</span></p>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled={page === 0} onClick={() => setPage(page - 1)} className="border-white/10 gap-1">
                <ChevronRight className="h-4 w-4" /> السابق
              </Button>
              <Button variant="outline" size="sm" disabled={page >= totalPages - 1} onClick={() => setPage(page + 1)} className="border-white/10 gap-1">
                التالي <ChevronLeft className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
