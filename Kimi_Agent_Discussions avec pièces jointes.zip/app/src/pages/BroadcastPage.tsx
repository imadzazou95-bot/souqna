import { useCallback, useEffect, useState } from 'react'
import { Radio, Plus, Loader2, Ban } from 'lucide-react'
import { broadcastService } from '@/services/broadcastService'
import { StatusBadge } from '@/components/StatusBadge'
import { EmptyState } from '@/components/EmptyState'
import { LoadingState, ErrorState, PageHeader } from '@/components/States'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Progress } from '@/components/ui/progress'
import type { Broadcast } from '@/types'
import { formatDate, formatNumber } from '@/utils/format'

const audienceOptions = [
  { value: 'all', label: 'كل المستخدمين' },
  { value: 'active', label: 'المستخدمون النشطون (7 أيام)' },
  { value: 'channel_members', label: 'مشتركو القناة' },
  { value: 'by_balance', label: 'حسب الرصيد (حد أدنى)' },
  { value: 'specific', label: 'مستخدمون محددون (Telegram IDs)' },
]

const messageTypes = [
  { value: 'text', label: 'نص' },
  { value: 'image', label: 'صورة' },
  { value: 'video', label: 'فيديو' },
  { value: 'button', label: 'زر' },
  { value: 'inline_keyboard', label: 'لوحة أزرار' },
]

export default function BroadcastPage() {
  const [broadcasts, setBroadcasts] = useState<Broadcast[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)
  const [createOpen, setCreateOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [toast, setToast] = useState<string | null>(null)
  const [form, setForm] = useState({
    title: '', text: '', audience: 'all', messageType: 'text',
    mediaUrl: '', minBalance: '', userIds: '',
  })

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      setBroadcasts(await broadcastService.list())
    } catch (e) {
      console.error(e)
      setError(true)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  const notify = (msg: string) => { setToast(msg); setTimeout(() => setToast(null), 4000) }

  const create = async () => {
    setSaving(true)
    try {
      const userIds = form.userIds.trim()
        ? form.userIds.split(/[\s,]+/).map((s) => Number(s)).filter((n) => !Number.isNaN(n))
        : undefined
      const res = await broadcastService.create({
        title: form.title.trim(),
        text: form.text.trim(),
        audience: form.audience as 'all',
        messageType: form.messageType as 'text',
        mediaUrl: form.mediaUrl.trim() || undefined,
        minBalance: form.minBalance ? Number(form.minBalance) : undefined,
        userIds,
      })
      setCreateOpen(false)
      setForm({ title: '', text: '', audience: 'all', messageType: 'text', mediaUrl: '', minBalance: '', userIds: '' })
      notify(`تم إنشاء الإذاعة — ${formatNumber(res?.recipients ?? 0)} مستلم. سيلتقطها n8n للإرسال.`)
      await load()
    } catch (e) {
      console.error(e)
      notify('حدث خطأ، حاول مرة أخرى')
    } finally {
      setSaving(false)
    }
  }

  const cancel = async (b: Broadcast) => {
    try {
      await broadcastService.cancel(b.broadcast_id)
      notify('تم إلغاء الإذاعة')
      await load()
    } catch (e) { console.error(e); notify('حدث خطأ') }
  }

  return (
    <div className="space-y-5">
      <PageHeader title="الإذاعة (Broadcast)" subtitle="الإرسال لا يتم من المتصفح — تُحفظ الرسالة ويرسلها n8n عبر Telegram Bot API"
        actions={<Button onClick={() => setCreateOpen(true)} className="bg-amber-400 text-amber-950 hover:bg-amber-300 font-bold gap-1.5">
          <Plus className="h-4 w-4" /> إذاعة جديدة
        </Button>} />

      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 rounded-xl border border-amber-400/30 bg-[hsl(220,24%,8%)] px-5 py-3 text-sm font-bold shadow-2xl animate-slide-up max-w-md text-center">{toast}</div>
      )}

      {error ? <ErrorState onRetry={load} /> : loading ? <LoadingState /> : broadcasts.length === 0 ? (
        <EmptyState icon={Radio} title="لا توجد إذاعات" description="أنشئ أول رسالة جماعية لمستخدمي البوت" actionLabel="إذاعة جديدة" onAction={() => setCreateOpen(true)} />
      ) : (
        <div className="space-y-3">
          {broadcasts.map((b) => (
            <div key={b.broadcast_id} className="glass-card p-5 space-y-3">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <h3 className="font-bold">{b.title ?? `إذاعة #${b.broadcast_id}`}</h3>
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{b.text}</p>
                </div>
                <StatusBadge status={b.status} />
              </div>
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <span>الجمهور: <span className="text-foreground">{audienceOptions.find((a) => a.value === b.audience)?.label ?? b.audience}</span></span>
                <span>{formatDate(b.created_at)}</span>
              </div>
              {b.total > 0 && (
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>أُرسلت: <span className="num text-emerald-300 font-bold">{formatNumber(b.sent)}</span></span>
                    <span>فشلت: <span className="num text-red-300 font-bold">{formatNumber(b.failed)}</span></span>
                    <span>الإجمالي: <span className="num font-bold">{formatNumber(b.total)}</span></span>
                  </div>
                  <Progress value={b.total ? (b.sent / b.total) * 100 : 0} className="h-1.5 bg-white/5" />
                </div>
              )}
              {(b.status === 'draft' || b.status === 'running') && (
                <Button size="sm" variant="outline" onClick={() => cancel(b)} className="border-red-400/30 text-red-400 gap-1.5">
                  <Ban className="h-3.5 w-3.5" /> إلغاء الإذاعة
                </Button>
              )}
            </div>
          ))}
        </div>
      )}

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="bg-[hsl(220,24%,7%)] border-white/10 text-foreground max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>إذاعة جديدة</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <Input placeholder="عنوان داخلي للإذاعة" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="bg-white/[0.03] border-white/10" />
            <Textarea placeholder="نص الرسالة…" value={form.text} onChange={(e) => setForm({ ...form, text: e.target.value })} className="bg-white/[0.03] border-white/10 min-h-[110px]" />
            <Select value={form.audience} onValueChange={(v) => setForm({ ...form, audience: v })}>
              <SelectTrigger className="bg-white/[0.03] border-white/10"><SelectValue placeholder="الجمهور" /></SelectTrigger>
              <SelectContent className="bg-[hsl(220,24%,8%)] border-white/10">
                {audienceOptions.map((a) => <SelectItem key={a.value} value={a.value}>{a.label}</SelectItem>)}
              </SelectContent>
            </Select>
            {form.audience === 'by_balance' && (
              <Input placeholder="الحد الأدنى للرصيد" type="number" dir="ltr" value={form.minBalance} onChange={(e) => setForm({ ...form, minBalance: e.target.value })} className="bg-white/[0.03] border-white/10 text-left" />
            )}
            {form.audience === 'specific' && (
              <Textarea placeholder="Telegram IDs مفصولة بفواصل" dir="ltr" value={form.userIds} onChange={(e) => setForm({ ...form, userIds: e.target.value })} className="bg-white/[0.03] border-white/10 text-left" />
            )}
            <Select value={form.messageType} onValueChange={(v) => setForm({ ...form, messageType: v })}>
              <SelectTrigger className="bg-white/[0.03] border-white/10"><SelectValue placeholder="نوع الرسالة" /></SelectTrigger>
              <SelectContent className="bg-[hsl(220,24%,8%)] border-white/10">
                {messageTypes.map((m) => <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>)}
              </SelectContent>
            </Select>
            {(form.messageType === 'image' || form.messageType === 'video') && (
              <Input placeholder="رابط الوسائط (URL)" dir="ltr" value={form.mediaUrl} onChange={(e) => setForm({ ...form, mediaUrl: e.target.value })} className="bg-white/[0.03] border-white/10 text-left" />
            )}
            <Button onClick={create} disabled={saving || !form.text.trim()} className="w-full bg-amber-400 text-amber-950 hover:bg-amber-300 font-bold">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'حفظ وإرسال عبر n8n'}
            </Button>
            <p className="text-[11px] text-muted-foreground">تُحفظ الإذاعة كمسودة ويلتقطها n8n (webhook: /api/webhooks/broadcast) ثم تُحدَّث حالة التسليم تلقائياً.</p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
