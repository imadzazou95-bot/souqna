import { useState } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router'
import {
  LayoutDashboard, Users, ArrowLeftRight, Wallet, UserPlus, Megaphone,
  ListChecks, CalendarCheck, Disc3, Radio, ShieldAlert, ScrollText, Settings,
  LogOut, Menu, X, Coins,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useAuth } from '@/hooks/useAuth'
import { Button } from '@/components/ui/button'

const navItems = [
  { to: '/', label: 'لوحة التحكم', icon: LayoutDashboard, roles: ['OWNER', 'ADMIN', 'SUPPORT'] },
  { to: '/users', label: 'المستخدمون', icon: Users, roles: ['OWNER', 'ADMIN', 'SUPPORT'] },
  { to: '/transactions', label: 'المعاملات', icon: ArrowLeftRight, roles: ['OWNER', 'ADMIN', 'SUPPORT'] },
  { to: '/withdrawals', label: 'السحوبات', icon: Wallet, roles: ['OWNER', 'ADMIN', 'SUPPORT'] },
  { to: '/referrals', label: 'الإحالات', icon: UserPlus, roles: ['OWNER', 'ADMIN', 'SUPPORT'] },
  { to: '/ads', label: 'الإعلانات', icon: Megaphone, roles: ['OWNER', 'ADMIN'] },
  { to: '/tasks', label: 'المهام', icon: ListChecks, roles: ['OWNER', 'ADMIN'] },
  { to: '/daily', label: 'المكافأة اليومية', icon: CalendarCheck, roles: ['OWNER', 'ADMIN', 'SUPPORT'] },
  { to: '/wheel', label: 'عجلة الحظ', icon: Disc3, roles: ['OWNER', 'ADMIN'] },
  { to: '/broadcast', label: 'الإذاعة', icon: Radio, roles: ['OWNER', 'ADMIN'] },
  { to: '/security', label: 'الأمان', icon: ShieldAlert, roles: ['OWNER', 'ADMIN', 'SUPPORT'] },
  { to: '/audit', label: 'سجل الإجراءات', icon: ScrollText, roles: ['OWNER', 'ADMIN'] },
  { to: '/settings', label: 'الإعدادات', icon: Settings, roles: ['OWNER'] },
]

const roleLabels: Record<string, string> = { OWNER: 'المالك', ADMIN: 'مشرف', SUPPORT: 'دعم' }

export function AdminLayout() {
  const { admin, signOut } = useAuth()
  const navigate = useNavigate()
  const [mobileOpen, setMobileOpen] = useState(false)

  const items = navItems.filter((i) => admin && i.roles.includes(admin.role))

  const handleSignOut = async () => {
    await signOut()
    navigate('/login')
  }

  const sidebar = (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-3 px-5 py-6 border-b border-white/[0.06]">
        <div className="rounded-xl bg-gradient-to-br from-amber-300 to-amber-600 p-2 gold-glow">
          <Coins className="h-6 w-6 text-amber-950" />
        </div>
        <div>
          <p className="font-extrabold text-lg gold-text leading-tight">TFARAJ</p>
          <p className="text-[11px] text-muted-foreground">Rewards Dashboard</p>
        </div>
      </div>
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        {items.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            onClick={() => setMobileOpen(false)}
            className={({ isActive }) => cn(
              'flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-semibold transition-all duration-200',
              isActive
                ? 'bg-amber-400/10 text-amber-300 border border-amber-400/25'
                : 'text-muted-foreground hover:bg-white/[0.04] hover:text-foreground border border-transparent'
            )}
          >
            <Icon className="h-[18px] w-[18px] shrink-0" />
            {label}
          </NavLink>
        ))}
      </nav>
      <div className="border-t border-white/[0.06] p-4">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <p className="text-sm font-bold truncate">{admin?.full_name ?? admin?.email}</p>
            <p className="text-xs text-amber-400/80">{roleLabels[admin?.role ?? ''] ?? ''}</p>
          </div>
          <Button variant="ghost" size="icon" onClick={handleSignOut} title="تسجيل الخروج"
            className="text-muted-foreground hover:text-red-400 hover:bg-red-400/10">
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop sidebar */}
      <aside className="hidden lg:fixed lg:inset-y-0 lg:right-0 lg:z-40 lg:block lg:w-64 border-l border-white/[0.06] bg-[hsl(222,28%,4.5%)]">
        {sidebar}
      </aside>

      {/* Mobile header */}
      <header className="lg:hidden sticky top-0 z-40 flex items-center justify-between border-b border-white/[0.06] bg-background/90 backdrop-blur-md px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="rounded-lg bg-gradient-to-br from-amber-300 to-amber-600 p-1.5">
            <Coins className="h-5 w-5 text-amber-950" />
          </div>
          <span className="font-extrabold gold-text">TFARAJ Rewards</span>
        </div>
        <Button variant="ghost" size="icon" onClick={() => setMobileOpen(!mobileOpen)}>
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </header>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <aside className="absolute inset-y-0 right-0 w-72 bg-[hsl(222,28%,4.5%)] border-l border-white/[0.06] animate-slide-up">
            {sidebar}
          </aside>
        </div>
      )}

      <main className="lg:mr-64 px-4 md:px-8 py-6 pb-24 lg:pb-8 max-w-[1400px]">
        <Outlet />
      </main>

      {/* Mobile bottom nav */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-40 border-t border-white/[0.06] bg-background/95 backdrop-blur-md">
        <div className="flex justify-around py-2">
          {items.slice(0, 5).map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to} end={to === '/'}
              className={({ isActive }) => cn(
                'flex flex-col items-center gap-1 px-2 py-1 text-[10px] font-semibold rounded-lg transition-colors',
                isActive ? 'text-amber-300' : 'text-muted-foreground'
              )}>
              <Icon className="h-5 w-5" />
              {label}
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  )
}
