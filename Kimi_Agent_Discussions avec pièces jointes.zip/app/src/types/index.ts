export type AdminRole = 'OWNER' | 'ADMIN' | 'SUPPORT'

export interface AdminUser {
  user_id: string
  email: string
  full_name: string | null
  role: AdminRole
  is_active: boolean
  created_at: string
}

export interface BotUser {
  id: number
  telegram_id: number
  username: string | null
  first_name: string | null
  last_name: string | null
  language: string | null
  points: number
  coins: number
  referred_by: number | null
  referral_code: string
  referral_count: number
  daily_streak: number
  last_daily_claim: string | null
  last_wheel_spin: string | null
  wheel_spins_available: number
  total_ads_watched: number
  total_points_earned: number
  total_points_spent: number
  total_withdrawn: number
  status: 'active' | 'inactive' | 'banned' | 'suspicious' | 'pending_verification'
  is_banned: boolean
  is_suspicious: boolean
  rewards_frozen: boolean
  is_channel_member: boolean
  level: number
  created_at: string
  last_activity: string
}

export type TransactionType =
  | 'daily_bonus' | 'wheel_reward' | 'ad_reward' | 'referral_reward' | 'task_reward'
  | 'withdrawal' | 'admin_adjustment' | 'bonus' | 'penalty' | 'promo_reward'
  | 'signup_bonus' | 'reversal'

export interface Transaction {
  id: number
  user_id: number
  type: TransactionType
  currency: 'points' | 'coins'
  amount: number
  balance_before: number
  balance_after: number
  reference_id: string | null
  description: string | null
  status: string
  created_at: string
  users?: { telegram_id: number; username: string | null; first_name: string | null } | null
}

export type WithdrawalStatus = 'pending' | 'processing' | 'approved' | 'rejected' | 'completed'

export interface Withdrawal {
  withdrawal_id: number
  user_id: number
  amount: number
  method: string
  destination: string
  status: WithdrawalStatus
  admin_note: string | null
  created_at: string
  processed_at: string | null
  users?: { telegram_id: number; username: string | null; first_name: string | null; points: number } | null
}

export interface Referral {
  id: number
  inviter_id: number
  invited_id: number
  status: 'pending' | 'rewarded' | 'frozen' | 'rejected'
  reward: number
  created_at: string
  rewarded_at: string | null
}

export interface AdTask {
  id: number
  code: string
  provider_id: number | null
  title: string | null
  reward: number
  daily_limit: number | null
  is_active: boolean
  created_at: string
  ad_providers?: { name: string; is_active: boolean } | null
}

export interface AdProvider {
  id: number
  name: string
  is_active: boolean
  config: Record<string, unknown>
}

export interface AdSession {
  id: string
  user_id: number
  ad_task_id: number
  status: 'started' | 'completed' | 'expired' | 'rejected'
  started_at: string
  completed_at: string | null
}

export interface Task {
  id: number
  title: string
  description: string | null
  reward: number
  type: string
  url: string | null
  status: 'active' | 'paused' | 'ended'
  start_at: string | null
  end_at: string | null
  max_completions: number | null
  verification_method: string
  created_at: string
}

export interface DailyClaim {
  id: number
  user_id: number
  claim_date: string
  streak_day: number
  reward_type: string
  reward: number
  created_at: string
}

export interface WheelSpin {
  wheel_spin_id: string
  user_id: number
  segment: number
  reward: number
  created_at: string
}

export interface Broadcast {
  broadcast_id: number
  title: string | null
  text: string
  status: 'draft' | 'running' | 'done' | 'cancelled'
  audience: string
  message_type: string
  media_url: string | null
  total: number
  sent: number
  failed: number
  blocked: number
  created_at: string
}

export interface SuspiciousEvent {
  id: number
  telegram_id: number
  reason: string
  severity: number
  metadata: Record<string, unknown> | null
  reviewed: boolean
  created_at: string
}

export interface AuditLog {
  id: number
  admin_id: string | null
  admin_email: string | null
  action: string
  target_type: string | null
  target_id: string | null
  old_value: Record<string, unknown> | null
  new_value: Record<string, unknown> | null
  created_at: string
}

export interface DashboardStats {
  total_users: number
  active_today: number
  new_today: number
  new_yesterday: number
  active_yesterday: number
  total_points_granted: number
  total_points_withdrawn: number
  withdrawals_total: number
  withdrawals_pending: number
  ads_completed_today: number
  referrals_today: number
  suspicious_users: number
  suspicious_events_open: number
  channel_members: number
  channel_non_members: number
  points_granted_today: number
  points_granted_yesterday: number
}

export interface TimeseriesPoint {
  day: string
  new_users: number
  active_users: number
  points_granted: number
  points_spent: number
  withdrawals: number
  ads_completed: number
  referrals: number
}
