import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import { authService } from '@/services/authService'
import type { AdminUser } from '@/types'

interface AuthState {
  loading: boolean
  admin: AdminUser | null
  signIn: (email: string, password: string) => Promise<void>
  signOut: () => Promise<void>
  refresh: () => Promise<void>
}

const AuthContext = createContext<AuthState | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [loading, setLoading] = useState(true)
  const [admin, setAdmin] = useState<AdminUser | null>(null)

  const loadProfile = async () => {
    try {
      const session = await authService.getSession()
      if (!session) {
        setAdmin(null)
        return
      }
      const profile = await authService.getAdminProfile()
      if (!profile || !profile.is_active) {
        await authService.signOut()
        setAdmin(null)
        return
      }
      setAdmin(profile)
    } catch {
      setAdmin(null)
    }
  }

  useEffect(() => {
    loadProfile().finally(() => setLoading(false))
    const { data: sub } = authService.onAuthChange((event) => {
      if (event === 'SIGNED_OUT') setAdmin(null)
      if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') loadProfile()
    })
    return () => sub.subscription.unsubscribe()
  }, [])

  const signIn = async (email: string, password: string) => {
    await authService.signIn(email, password)
    const profile = await authService.getAdminProfile()
    if (!profile || !profile.is_active) {
      await authService.signOut()
      throw new Error('not_authorized')
    }
    setAdmin(profile)
  }

  const signOut = async () => {
    await authService.signOut()
    setAdmin(null)
  }

  return (
    <AuthContext.Provider value={{ loading, admin, signIn, signOut, refresh: loadProfile }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
