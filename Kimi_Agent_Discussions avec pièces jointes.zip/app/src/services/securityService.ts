import { supabase } from '@/lib/supabase'
import type { AuditLog, SuspiciousEvent } from '@/types'

export const securityService = {
  async getSuspiciousUsers() {
    const { data, error } = await supabase
      .from('users')
      .select('id, telegram_id, username, first_name, points, is_suspicious, rewards_frozen, is_banned, status, last_activity')
      .or('is_suspicious.eq.true,rewards_frozen.eq.true')
      .order('last_activity', { ascending: false })
    if (error) throw error
    return data ?? []
  },

  async getEvents(reviewed: boolean | null = null): Promise<SuspiciousEvent[]> {
    let query = supabase.from('suspicious_events').select('*').order('created_at', { ascending: false }).limit(100)
    if (reviewed !== null) query = query.eq('reviewed', reviewed)
    const { data, error } = await query
    if (error) throw error
    return (data ?? []) as SuspiciousEvent[]
  },

  async reviewEvent(eventId: number, reviewed: boolean) {
    const { data, error } = await supabase.rpc('admin_review_suspicious_event', {
      p_event_id: eventId,
      p_reviewed: reviewed,
    })
    if (error) throw error
    return data
  },
}

export const auditService = {
  async list(page = 0, pageSize = 30): Promise<{ logs: AuditLog[]; total: number }> {
    const { data, error, count } = await supabase
      .from('audit_logs')
      .select('*', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(page * pageSize, (page + 1) * pageSize - 1)
    if (error) throw error
    return { logs: (data ?? []) as AuditLog[], total: count ?? 0 }
  },
}
