import { supabase } from '@/lib/supabase'
import type { Withdrawal, WithdrawalStatus } from '@/types'

export const withdrawalService = {
  async list(status: WithdrawalStatus | 'all' = 'all', page = 0, pageSize = 20) {
    let query = supabase
      .from('withdrawals')
      .select('*, users(telegram_id, username, first_name, points)', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(page * pageSize, (page + 1) * pageSize - 1)

    if (status !== 'all') query = query.eq('status', status)

    const { data, error, count } = await query
    if (error) throw error
    return { withdrawals: (data ?? []) as Withdrawal[], total: count ?? 0 }
  },

  async process(withdrawalId: number, action: 'approve' | 'reject' | 'processing' | 'complete', note?: string) {
    const { data, error } = await supabase.rpc('admin_process_withdrawal', {
      p_withdrawal_id: withdrawalId,
      p_action: action,
      p_note: note ?? null,
    })
    if (error) throw error
    return data
  },
}
