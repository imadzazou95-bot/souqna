import { supabase } from '@/lib/supabase'
import type { AdminRole, AdminUser } from '@/types'

export const authService = {
  async signIn(email: string, password: string) {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) throw error
    return data
  },

  async signOut() {
    await supabase.auth.signOut()
  },

  async getSession() {
    const { data } = await supabase.auth.getSession()
    return data.session
  },

  async getAdminProfile(): Promise<AdminUser | null> {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return null
    const { data, error } = await supabase
      .from('admin_users')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle()
    if (error) throw error
    return data
  },

  async getRole(): Promise<AdminRole | null> {
    const { data, error } = await supabase.rpc('current_admin_role')
    if (error) return null
    return data as AdminRole | null
  },

  onAuthChange(callback: (event: string) => void) {
    return supabase.auth.onAuthStateChange((event) => callback(event))
  },
}
