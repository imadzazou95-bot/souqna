import { supabase } from '@/lib/supabase'
import type { Task } from '@/types'

export const taskService = {
  async list(): Promise<Task[]> {
    const { data, error } = await supabase.from('tasks').select('*').order('created_at', { ascending: false })
    if (error) throw error
    return (data ?? []) as Task[]
  },

  async create(task: Omit<Task, 'id' | 'created_at'>) {
    const { data, error } = await supabase.from('tasks').insert(task).select().single()
    if (error) throw error
    return data
  },

  async update(id: number, patch: Partial<Task>) {
    const { error } = await supabase.from('tasks').update(patch).eq('id', id)
    if (error) throw error
  },

  async getCompletionCounts() {
    const { data, error } = await supabase.from('task_completions').select('task_id')
    if (error) throw error
    const counts: Record<number, number> = {}
    for (const row of data ?? []) counts[row.task_id] = (counts[row.task_id] ?? 0) + 1
    return counts
  },
}
