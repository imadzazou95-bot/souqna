import { supabase } from '@/lib/supabase'
import type { BotUser } from '@/types'

export interface UserFilters {
  search?: string
  status?: 'active' | 'blocked' | 'suspicious' | 'channel_member' | 'not_channel_member' | 'all'
}

export const userService = {
  async list(filters: UserFilters, page = 0, pageSize = 20) {
    let query = supabase
      .from('users')
      .select('*', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(page * pageSize, (page + 1) * pageSize - 1)

    if (filters.search) {
      const s = filters.search.trim()
      const numeric = /^\d+$/.test(s)
      query = numeric
        ? query.or(`telegram_id.eq.${s},username.ilike.%${s}%,first_name.ilike.%${s}%,last_name.ilike.%${s}%`)
        : query.or(`username.ilike.%${s}%,first_name.ilike.%${s}%,last_name.ilike.%${s}%`)
    }
    if (filters.status === 'blocked') query = query.eq('is_banned', true)
    if (filters.status === 'suspicious') query = query.eq('is_suspicious', true)
    if (filters.status === 'channel_member') query = query.eq('is_channel_member', true)
    if (filters.status === 'not_channel_member') query = query.eq('is_channel_member', false)
    if (filters.status === 'active') query = query.eq('is_banned', false).eq('status', 'active')

    const { data, error, count } = await query
    if (error) throw error
    return { users: (data ?? []) as BotUser[], total: count ?? 0 }
  },

  async getById(id: number): Promise<BotUser | null> {
    const { data, error } = await supabase.from('users').select('*').eq('id', id).maybeSingle()
    if (error) throw error
    return data
  },

  async getUserActivity(userId: number) {
    const [transactions, referralsMade, referralsGot, ads, daily, spins, withdrawals, suspicious] = await Promise.all([
      supabase.from('transactions').select('*').eq('user_id', userId).order('created_at', { ascending: false }).limit(50),
      supabase.from('referrals').select('*, invited:users!referrals_invited_id_fkey(telegram_id, username, first_name)').eq('inviter_id', userId).order('created_at', { ascending: false }).limit(50),
      supabase.from('referrals').select('*').eq('invited_id', userId).maybeSingle(),
      supabase.from('ad_sessions').select('*, ad_tasks(title, reward)').eq('user_id', userId).order('started_at', { ascending: false }).limit(50),
      supabase.from('daily_claims').select('*').eq('user_id', userId).order('claim_date', { ascending: false }).limit(30),
      supabase.from('wheel_spins').select('*').eq('user_id', userId).order('created_at', { ascending: false }).limit(30),
      supabase.from('withdrawals').select('*').eq('user_id', userId).order('created_at', { ascending: false }).limit(30),
      supabase.from('suspicious_events').select('*').eq('telegram_id', userId).order('created_at', { ascending: false }).limit(30),
    ])
    return {
      transactions: transactions.data ?? [],
      referralsMade: referralsMade.data ?? [],
      referralsGot: referralsGot.data,
      ads: ads.data ?? [],
      daily: daily.data ?? [],
      spins: spins.data ?? [],
      withdrawals: withdrawals.data ?? [],
      suspicious: suspicious.data ?? [],
    }
  },

  async setStatus(userId: number, flags: { status?: string; is_banned?: boolean; is_suspicious?: boolean; rewards_frozen?: boolean }) {
    const { data, error } = await supabase.rpc('admin_set_user_status', {
      p_user_id: userId,
      p_status: flags.status ?? null,
      p_is_banned: flags.is_banned ?? null,
      p_is_suspicious: flags.is_suspicious ?? null,
      p_rewards_frozen: flags.rewards_frozen ?? null,
    })
    if (error) throw error
    return data
  },

  async adjustBalance(userId: number, amount: number, description?: string) {
    const { data, error } = await supabase.rpc('admin_adjust_balance', {
      p_user_id: userId,
      p_amount: amount,
      p_description: description ?? null,
    })
    if (error) throw error
    return data
  },
}
