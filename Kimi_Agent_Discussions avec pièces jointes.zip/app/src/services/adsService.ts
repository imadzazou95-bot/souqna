import { supabase } from '@/lib/supabase'
import type { AdProvider, AdTask } from '@/types'

export const adsService = {
  async listTasks(): Promise<AdTask[]> {
    const { data, error } = await supabase
      .from('ad_tasks')
      .select('*, ad_providers(name, is_active)')
      .order('created_at', { ascending: false })
    if (error) throw error
    return (data ?? []) as AdTask[]
  },

  async listProviders(): Promise<AdProvider[]> {
    const { data, error } = await supabase.from('ad_providers').select('*').order('id')
    if (error) throw error
    return (data ?? []) as AdProvider[]
  },

  async createTask(task: { code: string; title: string; reward: number; daily_limit: number | null; provider_id: number | null }) {
    const { data, error } = await supabase.from('ad_tasks').insert({ ...task, is_active: true }).select().single()
    if (error) throw error
    return data
  },

  async updateTask(id: number, patch: Partial<AdTask>) {
    const { error } = await supabase.from('ad_tasks').update(patch).eq('id', id)
    if (error) throw error
  },

  async toggleTask(id: number, isActive: boolean) {
    const { error } = await supabase.from('ad_tasks').update({ is_active: isActive }).eq('id', id)
    if (error) throw error
  },

  async toggleProvider(id: number, isActive: boolean) {
    const { error } = await supabase.from('ad_providers').update({ is_active: isActive }).eq('id', id)
    if (error) throw error
  },

  async getSessionStats() {
    const { data, error } = await supabase.from('ad_sessions').select('status, started_at, completed_at')
    if (error) throw error
    const rows = data ?? []
    return {
      total: rows.length,
      started: rows.filter((r) => r.status === 'started').length,
      completed: rows.filter((r) => r.status === 'completed').length,
      expired: rows.filter((r) => r.status === 'expired').length,
      rejected: rows.filter((r) => r.status === 'rejected').length,
    }
  },
}
