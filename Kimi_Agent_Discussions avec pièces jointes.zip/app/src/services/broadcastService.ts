import { supabase } from '@/lib/supabase'
import type { Broadcast } from '@/types'

export const broadcastService = {
  async list(): Promise<Broadcast[]> {
    const { data, error } = await supabase
      .from('broadcasts')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50)
    if (error) throw error
    return (data ?? []) as Broadcast[]
  },

  async create(payload: {
    title: string
    text: string
    audience: 'all' | 'active' | 'channel_members' | 'specific' | 'by_balance'
    messageType: 'text' | 'image' | 'video' | 'button' | 'inline_keyboard'
    mediaUrl?: string
    buttons?: Array<{ text: string; url: string }>
    minBalance?: number
    userIds?: number[]
  }) {
    const { data, error } = await supabase.rpc('admin_create_broadcast', {
      p_title: payload.title,
      p_text: payload.text,
      p_audience: payload.audience,
      p_message_type: payload.messageType,
      p_media_url: payload.mediaUrl ?? null,
      p_buttons: payload.buttons ?? [],
      p_min_balance: payload.minBalance ?? null,
      p_user_ids: payload.userIds ?? null,
    })
    if (error) throw error
    return data
  },

  async cancel(broadcastId: number) {
    const { data, error } = await supabase.rpc('admin_cancel_broadcast', { p_broadcast_id: broadcastId })
    if (error) throw error
    return data
  },
}
