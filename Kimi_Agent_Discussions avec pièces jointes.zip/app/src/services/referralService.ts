import { supabase } from '@/lib/supabase'

export const referralService = {
  async list(status = 'all', page = 0, pageSize = 20) {
    let query = supabase
      .from('referrals')
      .select(`
        *,
        inviter:users!referrals_inviter_id_fkey(telegram_id, username, first_name),
        invited:users!referrals_invited_id_fkey(telegram_id, username, first_name, is_channel_member)
      `, { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(page * pageSize, (page + 1) * pageSize - 1)

    if (status !== 'all') query = query.eq('status', status)

    const { data, error, count } = await query
    if (error) throw error
    return { referrals: data ?? [], total: count ?? 0 }
  },

  async getStats() {
    const { data, error } = await supabase.from('referrals').select('status')
    if (error) throw error
    const rows = data ?? []
    return {
      total: rows.length,
      pending: rows.filter((r) => r.status === 'pending').length,
      rewarded: rows.filter((r) => r.status === 'rewarded').length,
      frozen: rows.filter((r) => r.status === 'frozen').length,
      rejected: rows.filter((r) => r.status === 'rejected').length,
    }
  },
}
