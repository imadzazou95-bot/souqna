import { supabase } from '@/lib/supabase'
import type { Transaction, TransactionType } from '@/types'

export const transactionService = {
  async list(filters: { type?: TransactionType | 'all'; search?: string }, page = 0, pageSize = 25) {
    let query = supabase
      .from('transactions')
      .select('*, users(telegram_id, username, first_name)', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(page * pageSize, (page + 1) * pageSize - 1)

    if (filters.type && filters.type !== 'all') query = query.eq('type', filters.type)

    const { data, error, count } = await query
    if (error) throw error
    return { transactions: (data ?? []) as Transaction[], total: count ?? 0 }
  },
}
