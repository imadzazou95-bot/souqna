import { supabase } from '@/lib/supabase'

export const dailyService = {
  async getStats() {
    const tz = ((await settingsService.get('timezone')) as string | null) ?? 'Africa/Algiers'
    const today = new Intl.DateTimeFormat('en-CA', { timeZone: tz }).format(new Date())
    const { data, error } = await supabase.from('daily_claims').select('*').order('created_at', { ascending: false }).limit(100)
    if (error) throw error
    const rows = data ?? []
    const { count: total } = await supabase.from('daily_claims').select('id', { count: 'exact', head: true })
    return {
      total: total ?? 0,
      today: rows.filter((r) => r.claim_date === today).length,
      recent: rows,
      timezone: tz,
    }
  },
}

export const wheelService = {
  async getStats() {
    const { data, error } = await supabase.from('wheel_spins').select('*').order('created_at', { ascending: false }).limit(200)
    if (error) throw error
    const rows = data ?? []
    const { count: total } = await supabase.from('wheel_spins').select('wheel_spin_id', { count: 'exact', head: true })
    const bySegment: Record<number, number> = {}
    for (const r of rows) bySegment[r.segment] = (bySegment[r.segment] ?? 0) + 1
    return { total: total ?? 0, recent: rows.slice(0, 30), bySegment }
  },

  async getConfig(settings: Record<string, unknown>) {
    return {
      enabled: settings.wheel_enabled === true,
      maxDailySpins: Number(settings.wheel_max_daily_spins ?? 5),
      minBalance: Number(settings.wheel_min_balance ?? 0),
      rewards: Array.from({ length: 8 }, (_, i) => Number(settings[`wheel_reward_${i + 1}`] ?? 0)),
    }
  },
}

export const settingsService = {
  async getAll(): Promise<Record<string, unknown>> {
    const { data, error } = await supabase.from('settings').select('key, value')
    if (error) throw error
    const map: Record<string, unknown> = {}
    for (const row of data ?? []) map[row.key] = row.value
    return map
  },

  async get(key: string): Promise<unknown> {
    const { data } = await supabase.from('settings').select('value').eq('key', key).maybeSingle()
    return data?.value
  },

  async update(key: string, value: unknown) {
    const { data, error } = await supabase.rpc('admin_update_setting', {
      p_key: key,
      p_value: value,
    })
    if (error) throw error
    return data
  },
}
