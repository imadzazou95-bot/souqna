import { supabase } from '@/lib/supabase'
import type { DashboardStats, TimeseriesPoint } from '@/types'

export const dashboardService = {
  async getStats(): Promise<DashboardStats> {
    const { data, error } = await supabase.rpc('admin_dashboard_stats')
    if (error) throw error
    return data as DashboardStats
  },

  async getTimeseries(days = 7): Promise<TimeseriesPoint[]> {
    const { data, error } = await supabase.rpc('admin_timeseries', { p_days: days })
    if (error) throw error
    return (data ?? []) as TimeseriesPoint[]
  },
}
