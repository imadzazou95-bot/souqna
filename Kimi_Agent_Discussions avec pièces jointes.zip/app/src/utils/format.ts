export function formatNumber(n: number | null | undefined): string {
  if (n === null || n === undefined) return '0'
  return new Intl.NumberFormat('en-US').format(n)
}

export function formatDate(iso: string | null | undefined): string {
  if (!iso) return '—'
  try {
    return new Intl.DateTimeFormat('ar-DZ', {
      timeZone: 'Africa/Algiers',
      year: 'numeric', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit',
    }).format(new Date(iso))
  } catch {
    return iso
  }
}

export function formatDateShort(iso: string | null | undefined): string {
  if (!iso) return '—'
  try {
    return new Intl.DateTimeFormat('ar-DZ', {
      timeZone: 'Africa/Algiers', month: 'short', day: 'numeric',
    }).format(new Date(iso))
  } catch {
    return iso
  }
}

export function timeAgo(iso: string | null | undefined): string {
  if (!iso) return '—'
  const diff = Date.now() - new Date(iso).getTime()
  const minutes = Math.floor(diff / 60000)
  if (minutes < 1) return 'الآن'
  if (minutes < 60) return `منذ ${minutes} د`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `منذ ${hours} س`
  const days = Math.floor(hours / 24)
  if (days < 30) return `منذ ${days} يوم`
  return formatDate(iso)
}

export function pctChange(current: number, previous: number): number | null {
  if (!previous) return current > 0 ? 100 : null
  return Math.round(((current - previous) / previous) * 100)
}

export function displayName(u: { first_name?: string | null; last_name?: string | null; username?: string | null } | null | undefined): string {
  if (!u) return '—'
  const name = [u.first_name, u.last_name].filter(Boolean).join(' ')
  return name || (u.username ? `@${u.username}` : '—')
}
