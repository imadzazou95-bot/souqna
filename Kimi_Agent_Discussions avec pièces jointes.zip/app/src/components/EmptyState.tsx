import type { LucideIcon } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface EmptyStateProps {
  icon: LucideIcon
  title: string
  description?: string
  actionLabel?: string
  onAction?: () => void
}

export function EmptyState({ icon: Icon, title, description, actionLabel, onAction }: EmptyStateProps) {
  return (
    <div className="glass-card flex flex-col items-center justify-center py-16 px-6 text-center animate-fade-in">
      <div className="rounded-2xl border border-amber-400/15 bg-amber-400/5 p-4 mb-4">
        <Icon className="h-8 w-8 text-amber-400/70" />
      </div>
      <h3 className="text-lg font-bold">{title}</h3>
      {description && <p className="mt-1 text-sm text-muted-foreground max-w-sm">{description}</p>}
      {actionLabel && onAction && (
        <Button onClick={onAction} className="mt-5 bg-amber-400 text-amber-950 hover:bg-amber-300 font-bold">
          {actionLabel}
        </Button>
      )}
    </div>
  )
}
