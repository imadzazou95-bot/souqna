import { Loader2, RefreshCw, AlertTriangle } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function LoadingState({ label = 'جارٍ التحميل…' }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-muted-foreground gap-3">
      <Loader2 className="h-7 w-7 animate-spin text-amber-400" />
      <p className="text-sm">{label}</p>
    </div>
  )
}

export function ErrorState({ onRetry }: { onRetry?: () => void }) {
  return (
    <div className="glass-card flex flex-col items-center justify-center py-14 px-6 text-center">
      <div className="rounded-2xl border border-red-400/20 bg-red-400/5 p-4 mb-4">
        <AlertTriangle className="h-7 w-7 text-red-400" />
      </div>
      <h3 className="font-bold">حدث خطأ، حاول مرة أخرى</h3>
      <p className="mt-1 text-sm text-muted-foreground">تعذر تحميل البيانات من الخادم</p>
      {onRetry && (
        <Button onClick={onRetry} variant="outline" className="mt-4 gap-2 border-white/10">
          <RefreshCw className="h-4 w-4" /> إعادة المحاولة
        </Button>
      )}
    </div>
  )
}

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 mb-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight">{title}</h1>
        {subtitle && <p className="text-sm text-muted-foreground mt-1">{subtitle}</p>}
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  )
}
