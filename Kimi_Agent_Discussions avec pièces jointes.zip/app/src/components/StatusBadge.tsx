import { cn } from '@/lib/utils'

const badgeStyles: Record<string, string> = {
  // withdrawal / generic
  pending: 'bg-orange-400/10 text-orange-300 border-orange-400/25',
  processing: 'bg-sky-400/10 text-sky-300 border-sky-400/25',
  approved: 'bg-emerald-400/10 text-emerald-300 border-emerald-400/25',
  completed: 'bg-emerald-400/10 text-emerald-300 border-emerald-400/25',
  rejected: 'bg-red-400/10 text-red-300 border-red-400/25',
  // referral
  rewarded: 'bg-emerald-400/10 text-emerald-300 border-emerald-400/25',
  frozen: 'bg-violet-400/10 text-violet-300 border-violet-400/25',
  // user status
  active: 'bg-emerald-400/10 text-emerald-300 border-emerald-400/25',
  inactive: 'bg-white/5 text-muted-foreground border-white/10',
  banned: 'bg-red-400/10 text-red-300 border-red-400/25',
  suspicious: 'bg-orange-400/10 text-orange-300 border-orange-400/25',
  pending_verification: 'bg-sky-400/10 text-sky-300 border-sky-400/25',
  // ad sessions
  started: 'bg-sky-400/10 text-sky-300 border-sky-400/25',
  expired: 'bg-white/5 text-muted-foreground border-white/10',
  // broadcast
  draft: 'bg-white/5 text-muted-foreground border-white/10',
  running: 'bg-sky-400/10 text-sky-300 border-sky-400/25',
  done: 'bg-emerald-400/10 text-emerald-300 border-emerald-400/25',
  cancelled: 'bg-red-400/10 text-red-300 border-red-400/25',
  // tasks
  paused: 'bg-orange-400/10 text-orange-300 border-orange-400/25',
  ended: 'bg-white/5 text-muted-foreground border-white/10',
}

const labels: Record<string, string> = {
  pending: 'معلق', processing: 'قيد المعالجة', approved: 'مقبول', completed: 'مكتمل', rejected: 'مرفوض',
  rewarded: 'مؤهل', frozen: 'مجمّد', active: 'نشط', inactive: 'غير نشط', banned: 'محظور',
  suspicious: 'مشبوه', pending_verification: 'بانتظار التحقق',
  started: 'بدأ', expired: 'منتهي', draft: 'مسودة', running: 'قيد الإرسال', done: 'تم', cancelled: 'ملغي',
  paused: 'متوقف', ended: 'منتهي',
}

export function StatusBadge({ status, label }: { status: string; label?: string }) {
  return (
    <span className={cn(
      'inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold whitespace-nowrap',
      badgeStyles[status] ?? 'bg-white/5 text-muted-foreground border-white/10'
    )}>
      {label ?? labels[status] ?? status}
    </span>
  )
}
