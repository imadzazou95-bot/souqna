import type { LucideIcon } from 'lucide-react'
import { TrendingUp, TrendingDown, Minus } from 'lucide-react'
import { cn } from '@/lib/utils'
import { formatNumber } from '@/utils/format'
import { Skeleton } from '@/components/ui/skeleton'

interface StatCardProps {
  title: string
  value: number | string
  icon: LucideIcon
  change?: number | null
  tone?: 'gold' | 'green' | 'red' | 'orange' | 'blue'
  loading?: boolean
  suffix?: string
}

const tones = {
  gold: 'text-amber-400 bg-amber-400/10 border-amber-400/20',
  green: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20',
  red: 'text-red-400 bg-red-400/10 border-red-400/20',
  orange: 'text-orange-400 bg-orange-400/10 border-orange-400/20',
  blue: 'text-sky-400 bg-sky-400/10 border-sky-400/20',
}

export function StatCard({ title, value, icon: Icon, change, tone = 'gold', loading, suffix }: StatCardProps) {
  if (loading) {
    return (
      <div className="glass-card p-5">
        <Skeleton className="h-4 w-24 mb-3 bg-white/5" />
        <Skeleton className="h-8 w-32 bg-white/5" />
      </div>
    )
  }
  return (
    <div className="glass-card p-5 transition-all duration-300 hover:border-amber-400/20 hover:bg-white/[0.045] animate-fade-in">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm text-muted-foreground truncate">{title}</p>
          <p className="mt-2 text-2xl md:text-3xl font-extrabold num tracking-tight">
            {typeof value === 'number' ? formatNumber(value) : value}
            {suffix && <span className="text-sm font-medium text-muted-foreground mr-1">{suffix}</span>}
          </p>
          {change !== undefined && change !== null && (
            <div className={cn('mt-2 flex items-center gap-1 text-xs font-semibold',
              change > 0 ? 'text-emerald-400' : change < 0 ? 'text-red-400' : 'text-muted-foreground')}>
              {change > 0 ? <TrendingUp className="h-3.5 w-3.5" /> : change < 0 ? <TrendingDown className="h-3.5 w-3.5" /> : <Minus className="h-3.5 w-3.5" />}
              <span className="num">{Math.abs(change)}%</span>
              <span className="text-muted-foreground font-normal">عن أمس</span>
            </div>
          )}
        </div>
        <div className={cn('shrink-0 rounded-xl border p-2.5', tones[tone])}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </div>
  )
}
