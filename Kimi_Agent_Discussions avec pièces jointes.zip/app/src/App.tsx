import { Routes, Route, Navigate, useLocation } from 'react-router'
import { AuthProvider, useAuth } from '@/hooks/useAuth'
import { AdminLayout } from '@/layouts/AdminLayout'
import LoginPage from '@/pages/LoginPage'
import DashboardPage from '@/pages/DashboardPage'
import UsersPage from '@/pages/UsersPage'
import UserDetailPage from '@/pages/UserDetailPage'
import TransactionsPage from '@/pages/TransactionsPage'
import WithdrawalsPage from '@/pages/WithdrawalsPage'
import ReferralsPage from '@/pages/ReferralsPage'
import AdsPage from '@/pages/AdsPage'
import TasksPage from '@/pages/TasksPage'
import DailyPage from '@/pages/DailyPage'
import WheelPage from '@/pages/WheelPage'
import BroadcastPage from '@/pages/BroadcastPage'
import SecurityPage from '@/pages/SecurityPage'
import AuditLogsPage from '@/pages/AuditLogsPage'
import SettingsPage from '@/pages/SettingsPage'
import { LoadingState } from '@/components/States'

function Protected() {
  const { loading, admin } = useAuth()
  const location = useLocation()
  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-background"><LoadingState /></div>
  }
  if (!admin) {
    return <Navigate to="/login" state={{ from: location }} replace />
  }
  return <AdminLayout />
}

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route element={<Protected />}>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/users" element={<UsersPage />} />
          <Route path="/users/:id" element={<UserDetailPage />} />
          <Route path="/transactions" element={<TransactionsPage />} />
          <Route path="/withdrawals" element={<WithdrawalsPage />} />
          <Route path="/referrals" element={<ReferralsPage />} />
          <Route path="/ads" element={<AdsPage />} />
          <Route path="/tasks" element={<TasksPage />} />
          <Route path="/daily" element={<DailyPage />} />
          <Route path="/wheel" element={<WheelPage />} />
          <Route path="/broadcast" element={<BroadcastPage />} />
          <Route path="/security" element={<SecurityPage />} />
          <Route path="/audit" element={<AuditLogsPage />} />
          <Route path="/settings" element={<SettingsPage />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AuthProvider>
  )
}
